sap.ui.define([
	"sap/ui/core/format/DateFormat"
], function(DateFormat) {
	"use strict";

	return {
		dateTime: function(date) {
			if (date !== undefined && date !== null) {
				var oLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale();
				var oDateFormat = DateFormat.getDateInstance({
					scale: "medium",
					pattern: "yyyy-MM-dd"
				}, oLocale);
				var subFromDate = oDateFormat.format(new Date(date));
				return subFromDate;
			} else {
				return "";
			}

		},
		
		// The below code added for Date Gap format
			dateTime2: function(date) {
				if (new Date(date) == "Invalid Date") {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd.MM.yyyy, HH:mm:ss"
				});
				var validDate = dateFormat.parse(date);
				if (validDate == "" || validDate == null || validDate == "Invalid Date") {
					return null;
				} else {
					date = validDate;
				}
			}
			if (date !== undefined && date !== null) {
				var oLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale();
				
				
				var oDateFormat = DateFormat.getDateInstance({
					scale: "medium",
					pattern: "dd-MMM-yyyy",
					UTC: true
				}, oLocale);

				var subFromDate = oDateFormat.format(new Date(date));
				/*var oTimeFormat = DateFormat.getTimeInstance({
					scale: "medium",
					pattern: "HH:mm:ss"
				}, oLocale);
				var subFromTime = oTimeFormat.format(new Date(date));
				return subFromDate + " " + subFromTime;*/
				return subFromDate;
			} else {
				return "";
			}

		
		},
			// This will be used for Logs and Tracking
			// Developer: Suman implemented as per the DateTime Gap
		dateTime2log : function(date) {
				if (new Date(date) == "Invalid Date") {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd.MM.yyyy, HH:mm:ss"
				});
				var validDate = dateFormat.parse(date);
				if (validDate == "" || validDate == null || validDate == "Invalid Date") {
					return null;
				} else {
					date = validDate;
				}
			}
			if (date !== undefined && date !== null) {
				var oLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale();
				
				
				var oDateFormat = DateFormat.getDateInstance({
					scale: "medium",
					pattern: "dd-MMM-yyyy"
				}, oLocale);

				var subFromDate = oDateFormat.format(new Date(date));
				var oTimeFormat = DateFormat.getTimeInstance({
					scale: "medium",
					pattern: "HH:mm:ss"
				}, oLocale);
				var subFromTime = oTimeFormat.format(new Date(date));
				return subFromDate + "T" + subFromTime;
					  
			} else {
				return "";
			}

		
		},
		oDataDateTimeFormatter: function(oDate) {
			if (new Date(oDate) == "Invalid Date") {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd.MM.yyyy"
				});
				var validDate = dateFormat.parse(oDate);
				if (validDate == "" || validDate == null || validDate == "Invalid Date") {
					return null;
				} else {
					oDate = validDate;
				}
			}

			//	oDate = new Date(new Date(oDate).setHours(0, 0, 0, 0));
			var parsedDate = null;
			var parsedTime = null;
			if (oDate !== "" && oDate !== null && oDate !== undefined) {
				dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd HH:mm:ss"
				});
				/*var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
					pattern: "KK:mm:ss a"
				});*/
				//	var timeStr = timeFormat.format(new Date(DepartureTime.ms + TZOffsetMs));
				//	var dateObject = new Date(oDate);
				//	var timeZoneOffsetMs = new Date(oDate).getTimezoneOffset() * 60 * 1000;
				//	var dateStr = dateFormat.format(new Date(dateObject.getTime() + timeZoneOffsetMs));
				//	var timeStr = timeFormat.format(new Date(oDate.getTime() + timeZoneOffsetMs));
				//	parsedDate = new Date(dateFormat.parse(dateStr).getTime());

				var oDateFormat = DateFormat.getDateInstance({
					scale: "medium",
					pattern: "yyyy-MM-dd"
				});
				var subFromDate = oDateFormat.format(new Date(oDate));
				var oTimeFormat = DateFormat.getTimeInstance({
					scale: "medium",
					pattern: "HH:mm:ss"
				});
				var subFromTime = oTimeFormat.format(new Date(oDate));
				return subFromDate + "T" + subFromTime;
			} else {
				return "";
			}
		},
		oDataDateTimeFormatterDatePicker: function(oDate) {
			if (new Date(oDate) === "Invalid Date") {
				var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd.MM.yyyy"
				});
				var validDate = dateFormat.parse(oDate);
				if (validDate === "" || validDate === null || validDate === "Invalid Date") {
					return null;
				} else {
					oDate = validDate;
				}
			}

			//	oDate = new Date(new Date(oDate).setHours(0, 0, 0, 0));
			//	oDate = new Date(new Date(oDate).setHours(0, 0, 0, 0));
			var parsedDate = null;
			var parsedTime = null;
			if (oDate !== "" && oDate !== null && oDate !== undefined) {
				dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy-MM-dd HH:mm:ss"
				});
				var dateObject = new Date(oDate);
				var timeZoneOffsetMs = new Date(oDate).getTimezoneOffset() * 60 * 1000;
				var dateStr = dateFormat.format(new Date(dateObject.getTime() - timeZoneOffsetMs));
				// //	var timeStr = timeFormat.format(new Date(oDate.getTime() + timeZoneOffsetMs));
				parsedDate = new Date(dateFormat.parse(dateStr).getTime());

				var oDateFormat = DateFormat.getDateInstance({
					scale: "medium",
					pattern: "yyyy-MM-dd"
				});
				var subFromDate = oDateFormat.format(new Date(parsedDate));
				var oTimeFormat = DateFormat.getTimeInstance({
					scale: "medium",
					pattern: "HH:mm:ss"
				});
				var subFromTime = oTimeFormat.format(new Date(parsedDate));
				return subFromDate + "T" + subFromTime;
			} else {
				return "";
			}
		}
	};
});