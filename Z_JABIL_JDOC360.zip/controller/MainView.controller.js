sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/ui/model/Filter', "sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text", 'sap/m/MessageToast', "sap/m/MessagePopoverItem",
	"sap/m/MessagePopover", "sap/ui/model/json/JSONModel",
	"JABIL_FINAL_JDOC360/model/formatter",
	'sap/viz/ui5/format/ChartFormatter',
	'sap/viz/ui5/api/env/Format',
		'sap/ui/core/util/Export',
		'sap/ui/core/util/ExportTypeCSV',
		"sap/ui/core/format/DateFormat"
		
], function(Controller, Filter, Dialog, Button, Text, MessageToast, MessagePopoverItem, MessagePopover, JSONModel, formatter,ChartFormatter, Format, Export, ExportTypeCSV, DateFormat ) {
	"use strict";

	return Controller.extend("JABIL_FINAL_JDOC360.controller.MainView", {
		formatter: formatter,
		onInit: function() {
			Format.numericFormatter(ChartFormatter.getInstance());
			var that = this;
			
		
			
			this.arraySiteInProcess = [];
			this.arrayDeptInProcess = [];
			this.arrayDocTypeInProcess = [];
			this.arrayCustomerInProcess = [];
			this.arrayStatusInProcess = [];
			this.arrayUserInProcess = [];
		

			this.arraySiteDocumentStatus = [];
			this.arrayAuthorOwnerDrop = [];
			this.arrayAuthorOwnerDrop1 = [];
			this.arrayDocTypeDropDocumentStatus = [];
			this.arrayCustomerDropDocumentStatus = [];

			this.arrayCustomerDocumentTypes = [];
			this.arrayStatusDocumentTypes = [];
			this.arrayAuthorOwnerDocumentTypes = [];
			this.arrayAuthorOwnerDocumentTypes1 = [];
			this.arraySiteDocumentTypes = [];
			this.arraydocumentTypes = [];

			this.arrayDeptPeriodicReview = [];
			this.arrayDocTypePeriodicReview = [];
			this.arrayCustomerPeriodicReview = [];
			this.arrayAuthorOwnerPeriodicReview = [];
			this.arrayAuthorOwnerPeriodicReview1 = [];
			this.arrayUserPeriodicReview = [];
			this.arraySitePeriodicReview = [];

			this.localNewJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			this.localNewJsonModelForPeriodicReviewChart = new sap.ui.model.json.JSONModel();
			this.localNewJsonModelForDocumentTypesChart = new sap.ui.model.json.JSONModel();
			this.localJsonModelForPeriodicReviewChart = new sap.ui.model.json.JSONModel();
			this.localJsonModelForDocumentTypesChart = new sap.ui.model.json.JSONModel();
			this.localNewJsonModelForDocStatusChart = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessSiteDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessDocTypeDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessDeptDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessStatusDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessPendingUsersDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForInProcessCustomersDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForDocumentStatusChart = new sap.ui.model.json.JSONModel();
			this.localJsonModelForDocStatusAuthorDropdown = new sap.ui.model.json.JSONModel();
			this.localJsonModelForDocStatusAuthorDropdown1 = new sap.ui.model.json.JSONModel();
			this.localJsonModelForDocumentTypesStatusDropdown = new sap.ui.model.json.JSONModel();
		
			
			
			var oJsonModelErrorLog = new sap.ui.model.json.JSONModel();
			var oJsonModelSite = new sap.ui.model.json.JSONModel();
			this.jsonModelForSite = new sap.ui.model.json.JSONModel();
			this.localInitialSite = "";
			
	
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			sap.ui.core.BusyIndicator.show(0);

			oModelVariantO1.read("SrchHelpGlbSiteSet", {
				success: function(oData, response) {
					that.jsonModelForSite.setData(oData);

					//	that.byId("titleId").setText("Error Log - " + oData.results.length);
				},
				error: function(err) {

				}
			});

			oModelVariantO1.read("JdocChartsSet", {

				urlParameters: {
					"$expand": [
						"NavToDocTypeChart,NavToSite,NavToDocStatusChart,NavToDocType,NavToOwner,NavToDocPrChart,NavToDepartment,NavToAuthor,NavToDocInChart,NavToCustomer,NavToPendingUser"
					]
				},
				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();
					//	console.log(oData);
					that.localJsonModelForInProcessChart.setData(oData.results[0].NavToDocInChart);
					that.localJsonModelForDocumentStatusChart.setData(oData.results[0].NavToDocStatusChart);
					that.localJsonModelForPeriodicReviewChart.setData(oData.results[0].NavToDocPrChart);
					that.localJsonModelForDocumentTypesChart.setData(oData.results[0].NavToDocTypeChart);
					//	that.byId("tableInprocess").setModel(that.localJsonModelForInProcessChart, "tabModel");
					that.localInitialSite = oData.results[0].NavToDocInChart.results[0].SiteId;
				
	
					that.byId("SiteIdString").setText(that.localInitialSite);
					that.byId("SiteIdStringDocStatus").setText(that.localInitialSite);
					that.byId("SiteIdStringDocType").setText(that.localInitialSite);
					that.byId("SiteIdStringPeriodicReview").setText(that.localInitialSite);

					var arrayFinal = oData.results[0].NavToDocInChart.results;
					var arrayFinalDocStatus = oData.results[0].NavToDocStatusChart.results;
					var arrayFinalPeriodicReview = oData.results[0].NavToDocPrChart.results;
					var arrayFinalDocumentTypes = oData.results[0].NavToDocTypeChart.results;
					var arrayJdocStatus = [];
					var arrayJdocNumbers = [];
					var arrayJdocStatusDocStatus = [];
					var arrayJdocNumbersDocStatus = [];
					var arrayJdocNumbersDocTypes = [];
					var arrayJdocNumbersDocTypes1 = [];
					var arrayJdocNumbersDocTypes1Temp = [];
					var arrayJdocStatusPeriodicReview = [];
					var arrayJdocNumbersPeriodicReview = [];
					var arrayJdocStatusDocumentTypes = [];
					var arrayJdocNumbersDocumentTypes = [];


										 /* *********************** */
										 /* 1. IN PROCESS DOCUMENTS  */
									    /* *********************** */
									    
					//	var inProcessFinalDocsArray = [];
					for (var a = 0; a < arrayFinal.length; a++) {
						var status = arrayFinal[a].JdocStatus;
						var jdocNo = arrayFinal[a].JdocNumber;
						var jdocRev = arrayFinal[a].JdocRevision;
						var pendingUser = arrayFinal[a].PendingUser;
						var wfName = arrayFinal[a].Workflow;
						var stepName = arrayFinal[a].Step;
					
						for (var b = arrayFinal.length - 1; b > a; b--) {
							if (arrayFinal[b].JdocNumber === jdocNo && arrayFinal[b].JdocRevision === jdocRev && arrayFinal[b].PendingUser ===
								pendingUser && arrayFinal[b].Workflow === wfName && arrayFinal[b].Step === stepName) {
								 arrayFinal.splice(b, 1);
									break;
							}
							/*else {
								docStatusFinalDocsArray.push(arrayFinalDocStatus[a]);
							}*/
						}
						//	inProcessFinalDocsArray.push(arrayFinalDocStatus[b]);

					}
					for (var i = 0; i < arrayFinal.length; i++) {
						arrayJdocStatus.push(arrayFinal[i].ProcessType);
						arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
					}
					
					
										/* *********************** */
										 /* 2. DOCUMENT STATUS  */
									    /* *********************** */
									    
									    
					//	var docStatusFinalDocsArray = [];
					for (a = 0; a < arrayFinalDocStatus.length; a++) {
						status = arrayFinalDocStatus[a].JdocStatus;
						jdocNo = arrayFinalDocStatus[a].JdocNumber;
						jdocRev = arrayFinalDocStatus[a].JdocRevision;
						
						for (b = arrayFinalDocStatus.length - 1; b > a; b--) {
							if (arrayFinalDocStatus[b].JdocStatus === status 
											&& arrayFinalDocStatus[b].JdocNumber === jdocNo 
												&& arrayFinalDocStatus[b].JdocRevision === jdocRev) {
								arrayFinalDocStatus.splice(b, 1);
								//	break;
							}
							/*else {
								docStatusFinalDocsArray.push(arrayFinalDocStatus[a]);
							}*/
						}
						//	docStatusFinalDocsArray.push(arrayFinalDocStatus[a]);

					}

					for (i = 0; i < arrayFinalDocStatus.length; i++) {
						arrayJdocStatusDocStatus.push(arrayFinalDocStatus[i].JdocStatus);
						// arrayJdocNumbersDocStatus.push(arrayFinalDocStatus[i].JdocNumber);
						//	arrayJdocNumbersDocStatus.push(arrayFinalDocStatus[i].JdocRevision);
						
						//MTest-JDoc360-App-Issue#262
						
						var arrayjdocstatus = {"JdocNumber": arrayFinalDocStatus[i].JdocNumber,"JdocRevision":arrayFinalDocStatus[i].JdocRevision };
						arrayJdocNumbersDocStatus.push(arrayjdocstatus);
						arrayJdocNumbersDocTypes.push(arrayFinalDocStatus[i].JdocNumber);
					}
					
										/* *********************** */
										 /* 3. DOCUMENT TYPES		  */
									    /* *********************** */
					
					for (a = 0; a < arrayFinalDocumentTypes.length; a++) {
						jdocNo = arrayFinalDocumentTypes[a].JdocNumber;
						jdocRev = arrayFinalDocumentTypes[a].JdocRevision;
						for (b = arrayFinalDocumentTypes.length - 1; b > a; b--) {
							if (arrayFinalDocumentTypes[b].JdocNumber === jdocNo 
									&& arrayFinalDocumentTypes[b].JdocRevision === 	jdocRev) {
								arrayFinalDocumentTypes.splice(b, 1);
							}
						}
					}
				for (i = 0; i < arrayFinalDocumentTypes.length; i++) {
					//MTest-JDoc360-App-Issue#97
						// arrayJdocStatusDocumentTypes.push(arrayFinalDocumentTypes[i].TypeId +"-"+arrayFinalDocumentTypes[i].TypeDesc);
						var typeArray = {"TypeId":arrayFinalDocumentTypes[i].TypeId, "TypeDesc":arrayFinalDocumentTypes[i].TypeDesc,"SubType":arrayFinalDocumentTypes[i].SubType };
					arrayJdocNumbersDocTypes1Temp.push(typeArray);
					//arrayJdocStatusDocumentTypes.push(arrayFinalDocumentTypes[i].TypeDesc);
					arrayJdocNumbersDocumentTypes.push(arrayFinalDocumentTypes[i].JdocNumber);
					
						// var arrayjdoctypes = {
						// 	"JdocNumber": arrayFinalDocumentTypes[i].JdocNumber,
						// 	"JdocRevision":arrayFinalDocumentTypes[i].JdocRevision
						// 	};
						
					//	 arrayJdocNumbersDocumentTypes.push(arrayjdoctypes);
					}
					
					 arrayJdocNumbersDocTypes1 = arrayJdocNumbersDocTypes1Temp.filter((elem, index, self) => self.findIndex((t) => {return (t.TypeId === elem.TypeId && t.SubType === elem.SubType)}) === index);
					
					 //arrayJdocNumbersDocTypes1 = arrayJdocNumbersDocTypes1Temp.filter(function(value, index){ 
					 //	return arrayJdocNumbersDocTypes1Temp.indexOf(value) === index; 
					 	
					 //});
					
										/* *********************** */
										 /* 4. PERIODIC REVIEW	  */
									    /* *********************** */
									    
					for (a = 0; a < arrayFinalPeriodicReview.length; a++) {
						jdocNo = arrayFinalPeriodicReview[a].JdocNumber;
						jdocRev = arrayFinalPeriodicReview[a].JdocRevision;
						for (b = arrayFinalPeriodicReview.length - 1; b > a; b--) {
							if (arrayFinalPeriodicReview[b].JdocNumber === jdocNo && arrayFinalPeriodicReview[b].JdocRevision ===
								jdocRev) {
								arrayFinalPeriodicReview.splice(b, 1);
							}
						}
					}

					for (i = 0; i < arrayFinalPeriodicReview.length; i++) {
						arrayJdocStatusPeriodicReview.push(arrayFinalPeriodicReview[i].PrStatus);
						//arrayJdocNumbersPeriodicReview.push(arrayFinalPeriodicReview[i].JdocNumber);
					var arrayperiodicreview = {
						"JdocNumber": arrayFinalPeriodicReview[i].JdocNumber,
						"JdocRevision":arrayFinalPeriodicReview[i].JdocRevision
					};
					arrayJdocNumbersPeriodicReview.push(arrayperiodicreview);
					}

					arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					arrayJdocStatusDocStatus = arrayJdocStatusDocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbersDocStatus = arrayJdocNumbersDocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					arrayJdocStatusPeriodicReview = arrayJdocStatusPeriodicReview.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbersPeriodicReview = arrayJdocNumbersPeriodicReview.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					arrayJdocStatusDocumentTypes = arrayJdocStatusDocumentTypes.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					
					// arrayJdocNumbersDocTypes1 = arrayJdocNumbersDocTypes1.filter(function(x, j, a) {
					// 	return a.indexOf(x) === j;
					// });
					/*arrayJdocNumbersDocumentTypes = arrayJdocNumbersDocumentTypes.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					//	console.log(arrayJdocStatus);

					// var arrayOfJdocNumbers = [];
					// for (var k = 0; k < arrayFinal.length; k++) {
					// 	//	var counterForJdocStatus = 0;

					// 	arrayOfJdocNumbers.push(arrayFinal[k]);

					// }
					var arrayOfJdocNumbersDocStatus = [];
					for (var k = 0; k < arrayJdocNumbersDocStatus.length; k++) {
						//	var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinalDocStatus.length; j++) {
							//MTest-JDoc360-App-Issue#262
						if (arrayJdocNumbersDocStatus[k].JdocNumber === arrayFinalDocStatus[j].JdocNumber 
									&& arrayJdocNumbersDocStatus[k].JdocRevision === arrayFinalDocStatus[j].JdocRevision ) {

								arrayOfJdocNumbersDocStatus.push(arrayFinalDocStatus[j]);
								break;
							}
						}
					}
						
					
				var arrayOfJdocNumbersDocumentTypes = [];
					for (var k = 0; k < arrayJdocNumbersDocTypes.length; k++) {
						//	var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinalDocumentTypes.length; j++) {
							if (arrayJdocNumbersDocTypes[k] === arrayFinalDocumentTypes[j].JdocNumber) {

								arrayOfJdocNumbersDocumentTypes.push(arrayFinalDocumentTypes[j]);
								break;
							}

						}

					}
					
					var arrayOfJdocNumbersPeriodicReview = [];
					for (var k = 0; k < arrayJdocNumbersPeriodicReview.length; k++) {
						//	var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinalPeriodicReview.length; j++) {
						/*	if (arrayJdocNumbersPeriodicReview[k] === arrayFinalPeriodicReview[j].JdocNumber) {
								arrayOfJdocNumbersPeriodicReview.push(arrayFinalPeriodicReview[j]);
								break;
							}*/
							if (arrayJdocNumbersPeriodicReview[k].JdocNumber === arrayFinalPeriodicReview[j].JdocNumber
							&& arrayJdocNumbersPeriodicReview[k].JdocRevision === arrayFinalPeriodicReview[j].JdocRevision) {
								arrayOfJdocNumbersPeriodicReview.push(arrayFinalPeriodicReview[j]);
								break;
							}
						}
					}

			
					
					// 1. in process: counter
					var arrayOfStatus = [];
					for (var k = 0; k < arrayJdocStatus.length; k++) {
						var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinal.length; j++) {
							if (arrayJdocStatus[k] === arrayFinal[j].ProcessType) {
								counterForJdocStatus++;
							}
						}
						//MTest-JDOC360-App-Issue#258
						var data = {
							
							"TaskType": arrayJdocStatus[k],
							"Value": counterForJdocStatus
						};
						arrayOfStatus.push(data);
					}

					// 2. Document Status: counter
					var arrayOfStatusDocStatus = [];
					for (var k = 0; k < arrayJdocStatusDocStatus.length; k++) {
						var counterForJdocStatusDocStatus = 0;
						for (var j = 0; j < arrayOfJdocNumbersDocStatus.length; j++) {
							if (arrayJdocStatusDocStatus[k] === arrayOfJdocNumbersDocStatus[j].JdocStatus) {
								counterForJdocStatusDocStatus++;
							}
						}
						var data = {
							"Status": arrayJdocStatusDocStatus[k],
							"Value": counterForJdocStatusDocStatus
						};
						arrayOfStatusDocStatus.push(data);
					}
						// 3.Doucment Types: counter
					var arrayOfStatusDocumentTypes = [];
					for (var k = 0; k < arrayJdocNumbersDocTypes1.length; k++) {
						var counterForJdocStatusDocumentTypes = 0;
						for (var j = 0; j < arrayFinalDocumentTypes.length; j++) {
							//MTest-JDoc360-App-Issue#97: added TypeDesc
							 if (arrayJdocNumbersDocTypes1[k].TypeId === arrayFinalDocumentTypes[j].TypeId && arrayJdocNumbersDocTypes1[k].SubType === arrayFinalDocumentTypes[j].SubType) {
							 //if (arrayJdocStatusDocumentTypes[k] === arrayOfJdocNumbersDocumentTypes[j].TypeDesc) {
								counterForJdocStatusDocumentTypes++;
							}
						}
						var data = {
							"Status": arrayJdocNumbersDocTypes1[k].TypeId +"~"+ arrayJdocNumbersDocTypes1[k].SubType +"~"+ arrayJdocNumbersDocTypes1[k].TypeDesc,
							"Value": counterForJdocStatusDocumentTypes
						};
						arrayOfStatusDocumentTypes.push(data);
					}

				// 4. Periodic Review: counter
					var arrayOfStatusPeriodicReview = [];
					for (var k = 0; k < arrayJdocStatusPeriodicReview.length; k++) {
						var counterForJdocStatusPeriodicReview = 0;
						for (var j = 0; j < arrayOfJdocNumbersPeriodicReview.length; j++) {
							if (arrayJdocStatusPeriodicReview[k] === arrayOfJdocNumbersPeriodicReview[j].PrStatus) {
								counterForJdocStatusPeriodicReview++;
							}
						}
						var data = {
							"Status": arrayJdocStatusPeriodicReview[k],
							"Value": counterForJdocStatusPeriodicReview
						};
						arrayOfStatusPeriodicReview.push(data);
					}

				
					//	console.log(arrayOfStatus);
					that.localJsonModelForInProcessStatusDropdown.setData(arrayOfStatusDocumentTypes);
					that.localJsonModelForDocumentTypesStatusDropdown.setData(arrayOfStatusDocumentTypes);
					var oVizFrame2 = that.getView().byId("idpiechart2");
					//	var oPopOver = new sap.m.Popover();

					/*var oMessageTemplate = new MessagePopoverItem({
						title: '{Status}',
						type: '{Value}'

					});
					oMessageTemplate = new MessagePopoverItem();

					var oPopOver = new MessagePopover({
						items: {
							id: "messagePopover",
							path: '/',
							template: oMessageTemplate
						}
					});*/
					//	var oPopOver = that.getView().byId("idPopOverInProcess");
					//	oPopOver.connect(oVizFrame2.getVizUid());
					//	oPopOver.setFormatString(ChartFormatter.DefaultPattern.STANDARDFLOAT); 
					var oModel2 = new sap.ui.model.json.JSONModel();

					var data2 = {
						'DocStatus': arrayOfStatus
					};
					oModel2.setData(data2);

					//      3. Create Viz dataset to feed to the data to the graph
					var oDataset2 = new sap.viz.ui5.data.FlattenedDataset({
						dimensions: [{
							
							name: 'TaskType',
							value: "{TaskType}"
						}],

						measures: [{
							name: 'Value',
							value: '{Value}'
						}],

						data: {
							path: "/DocStatus"
						}
					});
					oVizFrame2.setDataset(oDataset2);
					oVizFrame2.setModel(oModel2);

					//      4.Set Viz properties
					oVizFrame2.setVizProperties({
						title: {
							text: "In-process Documents - " + arrayFinal.length
						},
						plotArea: {
							colorPalette: d3.scale.category10().range(),
							drawingEffect: "glossy",
							radius: "0.25"

						},
						dataLabel: {
							visible: true,
							type: "percentage"

						},
						interaction: {
							behaviorType: null
						},
						tooltip: {
							visible: true,
							layinChart: false,
							bodyMeasureValue: {
								type: "valueAndPercentage"
							}
						}

					});
					var feedSize2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "size",
							'type': "Measure",
							'values': ["Value"]
						}),
						feedColor2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "color",
							'type': "Dimension",
							'values': ["TaskType"]
						});
					oVizFrame2.addFeed(feedSize2);
					oVizFrame2.addFeed(feedColor2);

					var oVizFrame3 = that.getView().byId("idpiechart3");
					var oModel3 = new sap.ui.model.json.JSONModel();

					var data3 = {
						'DocStatus': arrayOfStatusDocStatus
					};
					oModel3.setData(data3);

					//      3. Create Viz dataset to feed to the data to the graph
					var oDataset3 = new sap.viz.ui5.data.FlattenedDataset({
						dimensions: [{
							name: 'Status',
							value: "{Status}"
						}],

						measures: [{
							name: 'Value',
							value: '{Value}'
						}],

						data: {
							path: "/DocStatus"
						}
					});
					oVizFrame3.setDataset(oDataset3);
					oVizFrame3.setModel(oModel3);

					//      4.Set Viz properties
					oVizFrame3.setVizProperties({
						title: {
							text: "Document Status - " + arrayOfJdocNumbersDocStatus.length
						},
						plotArea: {
							colorPalette: d3.scale.category10().range(),
							drawingEffect: "glossy",
							radius: "0.25"

						},
						dataLabel: {
							visible: true,
							type: "percentage"

						},
						interaction: {
							behaviorType: null
						},
						tooltip: {
							visible: true,
							layinChart: false,
							bodyMeasureValue: {
								type: "valueAndPercentage"
							}
						}

					});
					var feedSize3 = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "size",
							'type': "Measure",
							'values': ["Value"]
						}),
						feedColor3 = new sap.viz.ui5.controls.common.feeds.FeedItem({
							'uid': "color",
							'type': "Dimension",
							'values': ["Status"]
						});
					oVizFrame3.addFeed(feedSize3);
					oVizFrame3.addFeed(feedColor3);

					var oVizFrame4 = that.getView().byId("idpiechart4");
					var oModel4 = new sap.ui.model.json.JSONModel();

					var data4 = {
						'DocTypes': arrayOfStatusPeriodicReview
					};
					oModel4.setData(data4);
					oVizFrame4.setModel(oModel4);

					oVizFrame4.setVizProperties({
						title: {
							text: "Periodic Review Tasks - " + arrayOfJdocNumbersPeriodicReview.length
						},
						plotArea: {
							colorPalette: d3.scale.category20().range(),
							drawingEffect: "glossy",
							radius: "0.25"
						},
						dataLabel: {
							visible: true,
							type: "percentage"
						},
						interaction: {
							behaviorType: null
						},
						tooltip: {
							visible: true,
							layinChart: false,
							bodyMeasureValue: {
								type: "valueAndPercentage"
							}
						}
					});

					var oVizFrame33 = that.getView().byId("idpiechart33");
					var oModel33 = new sap.ui.model.json.JSONModel();

					var data33 = {
						'DocTypes': arrayOfStatusDocumentTypes
					};
					oModel33.setData(data33);
					oVizFrame33.setModel(oModel33);

					oVizFrame33.setVizProperties({
						title: {
							text: "Document Types - " + arrayJdocNumbersDocTypes1.length
						},
						plotArea: {
							colorPalette: d3.scale.category20().range(),
							drawingEffect: "glossy",
							radius: "0.25"
						},
						dataLabel: {
							visible: true,
							type: "percentage"
						},
						interaction: {
							behaviorType: null
						},
						tooltip: {
							visible: true,
							layinChart: false,
							bodyMeasureValue: {
								type: "valueAndPercentage"
							}
						}
					});

					that.localJsonModelForInProcessSiteDropdown.setData(oData.results[0].NavToSite);
					that.localJsonModelForInProcessDocTypeDropdown.setData(oData.results[0].NavToDocType);
					that.localJsonModelForInProcessDeptDropdown.setData(oData.results[0].NavToDepartment);
					that.localJsonModelForInProcessPendingUsersDropdown.setData(oData.results[0].NavToPendingUser);
					that.localJsonModelForInProcessCustomersDropdown.setData(oData.results[0].NavToCustomer);
					that.localJsonModelForDocStatusAuthorDropdown.setData(oData.results[0].NavToAuthor);
					that.localJsonModelForDocStatusAuthorDropdown1.setData(oData.results[0].NavToOwner);
					
				
					
					oModelVariantO1.read("ErrorLogDataSet", null, null, true,
						function(oData, response) {

							//console.log(oData);
							oJsonModelErrorLog.setData(oData);
							that.byId("errorLogTable").setModel(oJsonModelErrorLog, "tabModel");

							that.byId("titleId").setText("Error Log - " + oData.results.length);
						},
						function(err) {
							//alert("Service Failed");
						});

				},
				error: function(err) {
					//		alert("Service Failed");
				}
			});

		},
	onAfterRendering: function(evt) {
			/*	var link1=this.getView().byId("link1");
				var popover=this.getView().byId("popover");
					this.getView().byId("link1").attachBrowserEvent("mouseover", function() {
			popover.openBy(evt.getSource());

					});*/
			
		},
		
		/*onUserIdSelect: function(oEvent) {
			var userIdSelected = oEvent.getParameter("selectedRow").getBindingContext().getProperty("Bname");
			if (this.byId("authorDropDown").getTokens().length > 0) {
				this.byId("authorDropDown").addToken(new sap.m.Token({
					text: userIdSelected
				}));
			} else {
				this.byId("authorDropDown").setTokens([new sap.m.Token({
					text: userIdSelected
				})], [new sap.m.Token({
					text: userIdSelected
				})]);
			}
			this.byId("authorDropDown").setValue("");
		},
		handleSuggest: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var siteId = this.byId("siteDropdown").getSelectedKey();
			var aFilters = [];
			var filter1 = new sap.ui.model.Filter("SiteId", "EQ", siteId);
			aFilters.push(filter1);
			if (sTerm) {
				oEvent.getSource().getBinding("suggestionRows").sCustomParams = "search=" + sTerm;
			}
			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);

		},*/
		onBeforeVariantSaveLinkedDocs: function(oEvent) {
			var oSmrtFltrBar = this.byId("smartFilterBarLinkedDocs");

			var _CUSTOM = {};

			var siteSelected = this.byId("siteIdDropdownLinkedDocs").getSelectedKey();
			if (siteSelected.length > 0) {
				//	prTypeStr = prTypeStr.slice(0, -1);
				_CUSTOM.Site = siteSelected;
			} else {
				_CUSTOM.Site = "";
			}

			var docNumberSelected = this.byId("docNumberDropDown").getSelectedKeys();
			if (docNumberSelected.length > 0) {
				var match = false;
				var docNumStr = "";
				for (var i = 0; i < docNumberSelected.length; i++) {
					if (docNumberSelected[i] !== "") {
						match = true;
						docNumStr += docNumberSelected[i] + ",";
					}
				}
				if (match) {
					_CUSTOM.DocNum = docNumStr;
				}
			} else {
				_CUSTOM.DocNum = "";
			}

			oSmrtFltrBar.setFilterData({
				_CUSTOM: _CUSTOM
			});
		},
		onAfterVariantLoadLinkedDocs: function(oEvent) {
			var oSmrtFltrBar = this.byId("smartFilterBar");
			var that = this;

			var _CUSTOM = oSmrtFltrBar.getFilterData()._CUSTOM;

			//	var selectedSite = this.byId("siteDropdown").getSelectedKey();
			//	var site = this.byId("docTypeDropdown").getSelectedKeys();
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);

			if (_CUSTOM !== undefined) {
				if (_CUSTOM.Site !== undefined && _CUSTOM.Site !== "") {
					//site FIlter
					if (this.byId("siteIdDropdownLinkedDocs") !== undefined) {
						this.byId("siteIdDropdownLinkedDocs").setSelectedKey(_CUSTOM.Site);

						var oFilter1 = new sap.ui.model.Filter("SiteId", "EQ", _CUSTOM.Site);
						oModelVariantO1.read("SrchHelpLinkedJdocsSet", {
							filters: [oFilter1],
							success: function(data2) {
								var oModel2 = new JSONModel();
								oModel2.setData(data2);

								that.getView().setModel(oModel2, "docNumberModel");
								//	that.byId("docTypeDropdown").setSelectedKeys(oModel2.getData().results[0].TypeId);
							}
						}, this);

					}
				} else {
					//site FIlter
					if (this.byId("siteIdDropdownLinkedDocs") !== undefined) {
						this.byId("siteIdDropdownLinkedDocs").setSelectedKey([]);
					}
				}

				if (_CUSTOM.DocNum !== undefined && _CUSTOM.DocNum !== "") {
					if (this.byId("docNumberDropDown") !== undefined) {
						this.byId("docNumberDropDown").setSelectedKeys(_CUSTOM.DocNum.split(","));
					}
				} else {
					if (this.byId("docNumberDropDown") !== undefined) {
						this.byId("docNumberDropDown").setSelectedKeys([]);
					}
				}
			}

		},
		onBeforeVariantSaveMasterList: function(oEvent) {
			var oSmrtFltrBar = this.byId("smartFilterBarMasterList");

			var _CUSTOM = {};

			var siteSelected = this.byId("siteIdDropdownMasterList").getSelectedKey();
			if (siteSelected.length > 0) {
				//	prTypeStr = prTypeStr.slice(0, -1);
				_CUSTOM.Site = siteSelected;
			} else {
				_CUSTOM.Site = "";
			}

			oSmrtFltrBar.setFilterData({
				_CUSTOM: _CUSTOM
			});
		},
		onAfterVariantLoadMasterList: function(oEvent) {
			var oSmrtFltrBar = this.byId("smartFilterBarMasterList");
			//	var that = this;

			var _CUSTOM = oSmrtFltrBar.getFilterData()._CUSTOM;

			if (_CUSTOM !== undefined) {
				if (_CUSTOM.Site !== undefined && _CUSTOM.Site !== "") {
					//site FIlter
					if (this.byId("siteIdDropdownMasterList") !== undefined) {
						this.byId("siteIdDropdownMasterList").setSelectedKey(_CUSTOM.Site);
					} else {
						//site FIlter
						if (this.byId("siteIdDropdownMasterList") !== undefined) {
							this.byId("siteIdDropdownMasterList").setSelectedKey([]);
						}
					}
				}
			}

		},
		onBeforeVariantSaveControlledCopies: function(oEvent) {
			var oSmrtFltrBar = this.byId("smartFilterBarControlledCopiesReport");

			var _CUSTOM = {};

			var siteSelected = this.byId("siteIdDropdownControlledCopies").getSelectedKey();
			if (siteSelected.length > 0) {
				//	prTypeStr = prTypeStr.slice(0, -1);
				_CUSTOM.Site = siteSelected;
			} else {
				_CUSTOM.Site = "";
			}

			oSmrtFltrBar.setFilterData({
				_CUSTOM: _CUSTOM
			});
		},
		onAfterVariantLoadControlledCopies: function(oEvent) {
			var oSmrtFltrBar = this.byId("smartFilterBarControlledCopiesReport");
			//	var that = this;

			var _CUSTOM = oSmrtFltrBar.getFilterData()._CUSTOM;

			if (_CUSTOM !== undefined) {
				if (_CUSTOM.Site !== undefined && _CUSTOM.Site !== "") {
					//site FIlter
					if (this.byId("siteIdDropdownControlledCopies") !== undefined) {
						this.byId("siteIdDropdownControlledCopies").setSelectedKey(_CUSTOM.Site);
					} else {
						//site FIlter
						if (this.byId("siteIdDropdownControlledCopies") !== undefined) {
							this.byId("siteIdDropdownControlledCopies").setSelectedKey([]);
						}
					}
				}
			}
		},
		onBeforeRebindTableInProcess: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");
			if (this.selectedInProcessSector !== "") {
				var statusFilter = new sap.ui.model.Filter("ProcessType", "EQ", this.selectedInProcessSector);
				oBindingParams.filters.push(statusFilter);
				
				//MTest-JDoc360-App-Issue#260: commented the below to make ProcessType fixed for selected pie : Go button
				//this.selectedInProcessSector = "";
			}
			//	var column = this.byId("responsiveTableInProcessChart").getColumns()[3];
			//		this.getView().byId("responsiveTableInProcessChart").filter(column, this.selectedInProcessSector);

			var dateFields = ["EffectiveDate", "NotificationDate"];
			var filters = oBindingParams.filters;
			if (filters.length === 1) {
				var sPath = filters["0"].sPath;
				if (dateFields.indexOf(sPath) !== -1) {
					var dateField = filters["0"];
					dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
					dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
				}
			} else {
				if (filters.length > 1) {

					for (var i = 0; i < filters.length; i++) {
						sPath = filters[i].sPath;
						if (dateFields.indexOf(sPath) !== -1) {
							dateField = filters[i];
							dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
							dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
						}
					}
				}
			}

			var selectedSites = this.byId("siteIdDropdown").getSelectedKeys();

			if (selectedSites.length === 0) {
				this.byId("siteIdDropdown").setValueState("Error");
			} else {
				this.byId("siteIdDropdown").setValueState("None");
				var siteIdsSelected = this.byId("siteIdDropdown").getSelectedKeys();
				if (siteIdsSelected.length > 0) {
					for (var j = 0; j < siteIdsSelected.length; j++) {
						if (siteIdsSelected[j] !== "") {
							var typeIdFilter = new sap.ui.model.Filter("SiteId", "EQ", siteIdsSelected[j]);
							oBindingParams.filters.push(typeIdFilter);
							//	this.filter.push(typeIdFilter);
						}
					}
				}
			}
			
			if(this.byId("typeIdDropdown").getSelectedKeys().length !== 0){
			var selectedDocTypes = this.byId("typeIdDropdown").getSelectedKeys();
			}else{
				var selectedDocTypes = this.arrayDocTypeInProcess;
			}
			if (selectedDocTypes.length !== 0) {
				for (var k = 0; k < selectedDocTypes.length; k++) {
					if (selectedDocTypes[k] !== "") {
						var docTypeFilter = new sap.ui.model.Filter("TypeId", "EQ", selectedDocTypes[k]);
						oBindingParams.filters.push(docTypeFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedCustomers = this.byId("customerIdDropDown").getSelectedKeys();
			
			if(this.byId("customerIdDropDown").getSelectedKeys().length !== 0){
			var selectedCustomers = this.byId("customerIdDropDown").getSelectedKeys();
			}else{
				var selectedCustomers = this.arrayCustomerInProcess;
			}

			if (selectedCustomers.length !== 0) {
				for (var l = 0; l < selectedCustomers.length; l++) {
					if (selectedCustomers[l] !== "") {
						var custFilter = new sap.ui.model.Filter("Customer", "EQ", selectedCustomers[l]);
						oBindingParams.filters.push(custFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			//var selectedDept = this.byId("deptIdDropDown").getSelectedKeys();
			
			if(this.byId("deptIdDropDown").getSelectedKeys().length !== 0){
			var selectedDept = this.byId("deptIdDropDown").getSelectedKeys();
			}else{
				var selectedDept = this.arrayDeptInProcess;
			}

			if (selectedDept.length !== 0) {
				for (var m = 0; m < selectedDept.length; m++) {
					if (selectedDept[m] !== "") {
						var deptFilter = new sap.ui.model.Filter("Department", "EQ", selectedDept[m]);
						oBindingParams.filters.push(deptFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			//var selectedStatus = this.byId("statusDropDown").getSelectedKeys();
			if(this.byId("statusDropDown").getSelectedKeys().length !== 0){
			var selectedStatus = this.byId("statusDropDown").getSelectedKeys();
			}else{
				var selectedStatus = this.arrayStatusInProcess;
			}

			if (selectedStatus.length !== 0) {
				for (var n = 0; n < selectedStatus.length; n++) {
					if (selectedStatus[n] !== "") {
						var statusFilter = new sap.ui.model.Filter("JdocStatus", "EQ", selectedStatus[n]);
						oBindingParams.filters.push(statusFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedUser = this.byId("pendingUserDropDown").getSelectedKeys();
			if(this.byId("pendingUserDropDown").getSelectedKeys().length !== 0){
			var selectedUser = this.byId("pendingUserDropDown").getSelectedKeys();
			}else{
				var selectedUser = this.arrayUserInProcess;
			}

			if (selectedUser.length !== 0) {
				for (var o = 0; o < selectedUser.length; o++) {
					if (selectedUser[o] !== "") {
						var pendingUserFilters = new sap.ui.model.Filter("PendingUser", "EQ", selectedUser[o]);
						oBindingParams.filters.push(pendingUserFilters);
						//	this.filter.push(typeIdFilter);
					}
				}
			}
			
			// removinng duplicates for jdoc number
			// BEGIN 
			
			// END

		},
		onBeforeRebindTableDocStatus: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");

			if (this.selectedDocStatusSector !== "") {
				var statusFilter = new sap.ui.model.Filter("JdocStatus", "EQ", this.selectedDocStatusSector);
				oBindingParams.filters.push(statusFilter);
			
			//MTest-JDoc360-App-Issue#260: commented the below to make ProcessType fixed for selected pie
			//	this.selectedDocStatusSector = "";
			}

			var dateFields = ["CreatedDate", "EffectiveDate", "ExpirationDate", "ReleaseDate"];
			var filters = oBindingParams.filters;
			if (filters.length === 1) {
				var sPath = filters["0"].sPath;
				if (dateFields.indexOf(sPath) !== -1) {
					var dateField = filters["0"];
					dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
					dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
				}
			} else {
				if (filters.length > 1) {

					for (var i = 0; i < filters.length; i++) {
						sPath = filters[i].sPath;
						if (dateFields.indexOf(sPath) !== -1) {
							dateField = filters[i];
							dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
							dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
						}
					}
				}
			}

			var selectedSites = this.byId("siteIdDropdownDocStatus").getSelectedKeys();
			

			if (selectedSites.length === 0) {
				this.byId("siteIdDropdownDocStatus").setValueState("Error");
			} else {
				this.byId("siteIdDropdownDocStatus").setValueState("None");
				var siteIdsSelected = this.byId("siteIdDropdownDocStatus").getSelectedKeys();
				if (siteIdsSelected.length > 0) {
					for (var j = 0; j < siteIdsSelected.length; j++) {
						if (siteIdsSelected[j] !== "") {
							var typeIdFilter = new sap.ui.model.Filter("SiteId", "EQ", siteIdsSelected[j]);
							oBindingParams.filters.push(typeIdFilter);
							//	this.filter.push(typeIdFilter);
						}
					}
				}
			}

			// var selectedDocTypes = this.byId("typeIdDropdownDocStatus").getSelectedKeys();
				if(this.byId("typeIdDropdownDocStatus").getSelectedKeys().length !== 0){
			var selectedDocTypes = this.byId("typeIdDropdownDocStatus").getSelectedKeys();
			}else{
				var selectedDocTypes = this.arrayDocTypeDropDocumentStatus;
			}

			if (selectedDocTypes.length !== 0) {
				for (var k = 0; k < selectedDocTypes.length; k++) {
					if (selectedDocTypes[k] !== "") {
						var docTypeFilter = new sap.ui.model.Filter("TypeId", "EQ", selectedDocTypes[k]);
						oBindingParams.filters.push(docTypeFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedCustomers = this.byId("customerIdDropDownDocStatus").getSelectedKeys();
					if(this.byId("customerIdDropDownDocStatus").getSelectedKeys().length !== 0){
			var selectedCustomers = this.byId("customerIdDropDownDocStatus").getSelectedKeys();
			}else{
				var selectedCustomers = this.arrayCustomerDropDocumentStatus;
			}

			if (selectedCustomers.length !== 0) {
				for (var l = 0; l < selectedCustomers.length; l++) {
					if (selectedCustomers[l] !== "") {
						var custFilter = new sap.ui.model.Filter("Customer", "EQ", selectedCustomers[l]);
						oBindingParams.filters.push(custFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedAuthors = this.byId("authorIdDropDownDocStatus").getSelectedKeys();
				if(this.byId("authorIdDropDownDocStatus").getSelectedKeys().length !== 0){
			var selectedAuthors = this.byId("authorIdDropDownDocStatus").getSelectedKeys();
			}else{
				var selectedAuthors = this.arrayAuthorOwnerDrop;
			}

			if (selectedAuthors.length !== 0) {
				for (var m = 0; m < selectedAuthors.length; m++) {
					if (selectedAuthors[m] !== "") {
						var authorFilter = new sap.ui.model.Filter("AuthorId", "EQ", selectedAuthors[m]);
						oBindingParams.filters.push(authorFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedOwners = this.byId("ownerIdDropDownDocStatus").getSelectedKeys();
			if(this.byId("ownerIdDropDownDocStatus").getSelectedKeys().length !== 0){
			var selectedOwners = this.byId("ownerIdDropDownDocStatus").getSelectedKeys();
			}else{
				var selectedOwners = this.arrayAuthorOwnerDrop1;
			}

			if (selectedOwners.length !== 0) {
				for (var n = 0; n < selectedOwners.length; n++) {
					if (selectedOwners[n] !== "") {
						var ownerFilter = new sap.ui.model.Filter("OwnerId", "EQ", selectedOwners[n]);
						oBindingParams.filters.push(ownerFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}
		},
		onBeforeRebindTableDocType: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");

			if (this.selectedDocTypeSector !== "" ) {
				var statusTypeFilter = new sap.ui.model.Filter("TypeId", "EQ", this.selectedDocTypeSector);
				var statusSubTypeFilter = new sap.ui.model.Filter("SubType", "EQ", this.selectedDocSubTypeSector);
				// var statusFilter = [new Filter([
		  //                     new Filter("TypeId", "Contains", this.selectedDocTypeSector),
		  //                     new Filter("SubType", "Contains", this.selectedDocSubTypeSector)
		  //                                             ], false)];
				oBindingParams.filters.push(statusTypeFilter, statusSubTypeFilter);
			//MTest-JDoc360-App-Issue#260: commented the below to make ProcessType fixed for selected pie
			//	this.selectedDocTypeSector = "";
			}

			var dateFields = ["CreatedDate", "EffectiveDate", "ExpirationDate", "ReleaseDate"];
			var filters = oBindingParams.filters;
			if (filters.length === 1) {
				var sPath = filters["0"].sPath;
				if (dateFields.indexOf(sPath) !== -1) {
					var dateField = filters["0"];
					dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
					dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
				}
			} else {
				if (filters.length > 1) {

					for (var i = 0; i < filters.length; i++) {
						sPath = filters[i].sPath;
						if (dateFields.indexOf(sPath) !== -1) {
							dateField = filters[i];
							dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
							dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
						}
					}
				}
			}

			var selectedSites = this.byId("siteIdDropdownDocType").getSelectedKeys();

			if (selectedSites.length === 0) {
				this.byId("siteIdDropdownDocType").setValueState("Error");
			} else {
				this.byId("siteIdDropdownDocType").setValueState("None");
				var siteIdsSelected = this.byId("siteIdDropdownDocType").getSelectedKeys();
				if (siteIdsSelected.length > 0) {
					for (var j = 0; j < siteIdsSelected.length; j++) {
						if (siteIdsSelected[j] !== "") {
							var typeIdFilter = new sap.ui.model.Filter("SiteId", "EQ", siteIdsSelected[j]);
							oBindingParams.filters.push(typeIdFilter);
							//	this.filter.push(typeIdFilter);
						}
					}
				}
			}
			// var selectedStatus = this.byId("statusIdDropDownDocType").getSelectedKeys();
				if(this.byId("statusIdDropDownDocType").getSelectedKeys().length !== 0){
			var selectedStatus = this.byId("statusIdDropDownDocType").getSelectedKeys();
			}else{
				var selectedStatus = this.arrayStatusDocumentTypes;
			}

			if (selectedStatus.length !== 0) {
				for (var k = 0; k < selectedStatus.length; k++) {
					if (selectedStatus[k] !== "") {
						var statusFilter = new sap.ui.model.Filter("JdocStatus", "EQ", selectedStatus[k]);
						oBindingParams.filters.push(statusFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedCustomers = this.byId("customerIdDropDownDocType").getSelectedKeys();
				if(this.byId("customerIdDropDownDocType").getSelectedKeys().length !== 0){
			var selectedCustomers = this.byId("customerIdDropDownDocType").getSelectedKeys();
			}else{
				var selectedCustomers = this.arrayCustomerDocumentTypes;
			}

			if (selectedCustomers.length !== 0) {
				for (var l = 0; l < selectedCustomers.length; l++) {
					if (selectedCustomers[l] !== "") {
						var custFilter = new sap.ui.model.Filter("Customer", "EQ", selectedCustomers[l]);
						oBindingParams.filters.push(custFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedAuthors = this.byId("authorIdDropDownDocType").getSelectedKeys();
			if(this.byId("authorIdDropDownDocType").getSelectedKeys().length !== 0){
			var selectedAuthors = this.byId("authorIdDropDownDocType").getSelectedKeys();
			}else{
				var selectedAuthors = this.arrayAuthorOwnerDocumentTypes;
			}

			if (selectedAuthors.length !== 0) {
				for (var m = 0; m < selectedAuthors.length; m++) {
					if (selectedAuthors[m] !== "") {
						var authorFilter = new sap.ui.model.Filter("AuthorId", "EQ", selectedAuthors[m]);
						oBindingParams.filters.push(authorFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedOwners = this.byId("ownerIdDropDownDocType").getSelectedKeys();
			if(this.byId("ownerIdDropDownDocType").getSelectedKeys().length !== 0){
			var selectedOwners = this.byId("ownerIdDropDownDocType").getSelectedKeys();
			}else{
				var selectedOwners = this.arrayAuthorOwnerDocumentTypes1;
			}
			if (selectedOwners.length !== 0) {
				for (var n = 0; n < selectedOwners.length; n++) {
					if (selectedOwners[n] !== "") {
						var ownerFilter = new sap.ui.model.Filter("OwnerId", "EQ", selectedAuthors[n]);
						oBindingParams.filters.push(ownerFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}
		},
		onBeforeRebindTablePeriodicReview: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");

			if (this.selectedPeriodicReviewSector !== "") {
				var statusFilter = new sap.ui.model.Filter("PrStatus", "EQ", this.selectedPeriodicReviewSector);
				oBindingParams.filters.push(statusFilter);
		//MTest-JDoc360-App-Issue#260: commented the below to make ProcessType fixed for selected pie
				//this.selectedPeriodicReviewSector = "";
			}

			var dateFields = ["CreatedDate", "EffectiveDate", "ExpirationDate", "ReleaseDate"];
			var filters = oBindingParams.filters;
			if (filters.length === 1) {
				var sPath = filters["0"].sPath;
				if (dateFields.indexOf(sPath) !== -1) {
					var dateField = filters["0"];
					dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
					dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
				}
			} else {
				if (filters.length > 1) {

					for (var i = 0; i < filters.length; i++) {
						sPath = filters[i].sPath;
						if (dateFields.indexOf(sPath) !== -1) {
							dateField = filters[i];
							dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
							dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
						}
					}
				}
			}

			var selectedSites = this.byId("siteIdDropdownPeriodicReview").getSelectedKeys();

			if (selectedSites.length === 0) {
				this.byId("siteIdDropdownPeriodicReview").setValueState("Error");
			} else {
				this.byId("siteIdDropdownPeriodicReview").setValueState("None");
				var siteIdsSelected = this.byId("siteIdDropdownPeriodicReview").getSelectedKeys();
				if (siteIdsSelected.length > 0) {
					for (var j = 0; j < siteIdsSelected.length; j++) {
						if (siteIdsSelected[j] !== "") {
							var typeIdFilter = new sap.ui.model.Filter("SiteId", "EQ", siteIdsSelected[j]);
							oBindingParams.filters.push(typeIdFilter);
							//	this.filter.push(typeIdFilter);
						}
					}
				}
			}

			// var selectedDocTypes = this.byId("typeIdDropdownPeriodicReview").getSelectedKeys();
				if(this.byId("typeIdDropdownPeriodicReview").getSelectedKeys().length !== 0){
			var selectedDocTypes = this.byId("typeIdDropdownPeriodicReview").getSelectedKeys();
			}else{
				var selectedDocTypes = this.arrayDocTypePeriodicReview;
			}

			if (selectedDocTypes.length !== 0) {
				for (var k = 0; k < selectedDocTypes.length; k++) {
					if (selectedDocTypes[k] !== "") {
						var docTypeFilter = new sap.ui.model.Filter("TypeId", "EQ", selectedDocTypes[k]);
						oBindingParams.filters.push(docTypeFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedCustomers = this.byId("customerIdDropDownPeriodicReview").getSelectedKeys();
			if(this.byId("customerIdDropDownPeriodicReview").getSelectedKeys().length !== 0){
			var selectedCustomers = this.byId("customerIdDropDownPeriodicReview").getSelectedKeys();
			}else{
				var selectedCustomers = this.arrayCustomerPeriodicReview;
			}

			if (selectedCustomers.length !== 0) {
				for (var l = 0; l < selectedCustomers.length; l++) {
					if (selectedCustomers[l] !== "") {
						var custFilter = new sap.ui.model.Filter("Customer", "EQ", selectedCustomers[l]);
						oBindingParams.filters.push(custFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedAuthors = this.byId("authorIdDropDownPeriodicReview").getSelectedKeys();
			if(this.byId("authorIdDropDownPeriodicReview").getSelectedKeys().length !== 0){
			var selectedAuthors = this.byId("authorIdDropDownPeriodicReview").getSelectedKeys();
			}else{
				var selectedAuthors = this.arrayAuthorOwnerPeriodicReview;
			}

			if (selectedAuthors.length !== 0) {
				for (var m = 0; m < selectedAuthors.length; m++) {
					if (selectedAuthors[m] !== "") {
						var authorFilter = new sap.ui.model.Filter("AuthorId", "EQ", selectedAuthors[m]);
						oBindingParams.filters.push(authorFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedOwners = this.byId("ownerIdDropDownPeriodicReview").getSelectedKeys();
			if(this.byId("ownerIdDropDownPeriodicReview").getSelectedKeys().length !== 0){
			var selectedOwners = this.byId("ownerIdDropDownPeriodicReview").getSelectedKeys();
			}else{
				var selectedOwners = this.arrayAuthorOwnerPeriodicReview1;
			}

			if (selectedOwners.length !== 0) {
				for (var n = 0; n < selectedOwners.length; n++) {
					if (selectedOwners[n] !== "") {
						var ownerFilter = new sap.ui.model.Filter("OwnerId", "EQ", selectedAuthors[n]);
						oBindingParams.filters.push(ownerFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedDept = this.byId("deptIdDropDownPeriodicReview").getSelectedKeys();
				if(this.byId("deptIdDropDownPeriodicReview").getSelectedKeys().length !== 0){
			var selectedDept = this.byId("deptIdDropDownPeriodicReview").getSelectedKeys();
			}else{
				var selectedDept = this.arrayDeptPeriodicReview;
			}

			if (selectedDept.length !== 0) {
				for (var p = 0; p < selectedDept.length; p++) {
					if (selectedDept[p] !== "") {
						var deptFilter = new sap.ui.model.Filter("Department", "EQ", selectedDept[p]);
						oBindingParams.filters.push(deptFilter);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

			// var selectedUser = this.byId("pendingUserDropDownPeriodicReview").getSelectedKeys();
				if(this.byId("pendingUserDropDownPeriodicReview").getSelectedKeys().length !== 0){
			var selectedUser = this.byId("pendingUserDropDownPeriodicReview").getSelectedKeys();
			}else{
				var selectedUser = this.arrayUserPeriodicReview;
			}

			if (selectedUser.length !== 0) {
				for (var o = 0; o < selectedUser.length; o++) {
					if (selectedUser[o] !== "") {
						var pendingUserFilters = new sap.ui.model.Filter("PendingUser", "EQ", selectedUser[o]);
						oBindingParams.filters.push(pendingUserFilters);
						//	this.filter.push(typeIdFilter);
					}
				}
			}

		},
		masterListReport: function(evt) {
			if (!this._oMasterListReport) {
				this._oMasterListReport = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.MasterListReport", this);
				this.getView().addDependent(this._oMasterListReport);
			}
			this.byId("siteIdDropdownMasterList").setModel(this.jsonModelForSite, "siteModel");
			this.byId("siteIdDropdownMasterList").setSelectedKey(this.localInitialSite);
			this._oMasterListReport.open();
		//	this.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field09,Field10");
		//	var str1 = "09";
			//this.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field" + str1);
			
		//	this.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field01,Field02,Field03,Field04,Field05,Field06,Field07,Field08,Field09,Field10");
			// code added to get field list
		/*	var that = this;
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			var siteId = this.byId("siteIdDropdownMasterList").getSelectedKey();
			var oFilter = new sap.ui.model.Filter("SiteId", "EQ", siteId);
			var labelModel = new sap.ui.model.json.JSONModel();
				oModelVariantO1.read("SiteCustFldLabelsSet", {
				filters: [oFilter],

				success: function(oData, response) {
					var dataLabelObj = {
						"results": ""
					};
					var fieldList = [];
					for (var z = 0; z < oData.results.length; z++) {
						fieldList.push(oData.results[z].CustFieldLabel);
						
					}
					dataLabelObj.results = fieldList;
					labelModel.setData(dataLabelObj);
					that.getView().setModel(labelModel, "labelModel");
					// that.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field09,Field10");
					 //for(i= labelModel.getData().results.length; i< 10; i++) {
					 //	var str1 =+ Field +i;
					 //}
					//that.getView().byId("smartTableMasterList").setIgnoreFromPersonalisation("AuthorName");
				
					
				},
				
				error: function(err) {

				}
			});*/
		this.byId("smartTableMasterList").rebindTable();
		},
		onBeforeRebindTableMasterList: function(oEvent) {
			//this.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field09,Field10");
		
			var oBindingParams = oEvent.getParameter("bindingParams");
			// oBindingParams.preventTableBind = 'true';
			
			var selectedSite = this.byId("siteIdDropdownMasterList").getSelectedKey();

			var that = this;
			
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			var siteId = this.byId("siteIdDropdownMasterList").getSelectedKey();
			var oFilter = new sap.ui.model.Filter("SiteId", "EQ", siteId);
			var labelModel = new sap.ui.model.json.JSONModel();
		//	var str1 = "";
			var string= "";
		/*	var Field01 = "";
			var Field02 = "";
			var Field03 = "";
			var Field04 = "";
			var Field05 = "";
			var Field06 = "";
			var Field07 = "";
			var Field08 = "";
			var Field09 = "";
			var Field10 = "";*/
		
			var fieldList = [];
			oModelVariantO1.read("SiteCustFldLabelsSet", {
				filters: [oFilter],

				success: function(oData, response) {
					var dataLabelObj = {
						"results": ""
					};
					//var fieldList = [];
					
					for (var z = 0; z < oData.results.length; z++) {
						fieldList.push(oData.results[z].CustFieldLabel);
					/*	str1 = fieldList.slice(0);
						Field01 = str1[0];
						Field02 = str1[1];
						Field03 = str1[2];
						Field04 = str1[3];
						Field05 = str1[4];
						Field06 = str1[5];
						Field07 = str1[6];
						Field08 = str1[7];
						Field09 = str1[8];
						Field10 = str1[9];*/
						
						
					}
					dataLabelObj.results = fieldList;
					labelModel.setData(dataLabelObj);
					that.getView().setModel(labelModel, "labelModel");
				
					var str ="";
					
							for( var j = fieldList.length +1 ; j <= 10;  j++) {
								 str += "Field"+ j +",";
							}
							string = str.slice(0 , str.length -1);
							//that.byId("smartTableMasterList").setIgnoreFromPersonalisation(string);
							//that.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field09,Field10");
						},
						
						error: function(err) {

				}
			});
			// that.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field09,Field10");
				/*var str ="";
					for( var j = fieldList.length +1 ; j < 10;  j++) {
						 str += "Field0"+ j +",";
			}
			var string = str.slice(0 , str.length -1);*/
			
			
			/*
			if(Field01 ==="" || Field01 === undefined){
				 str1 += "Field01" + ",";
			}
			if(Field02 ==="" || Field02 === undefined){
				 str1 += "Field02" + ",";
			}
			if(Field03 ==="" || Field03 === undefined){
				 str1 += "Field03" + ",";
			}
			if(Field04 ==="" || Field04 === undefined){
				str1 += "Field04" + ",";
			}
			if(Field05 ==="" || Field05 === undefined){
				str1 += "Field05" + ",";
			}
			if(Field06 ==="" || Field06 === undefined){
				str1 += "Field06" + ",";
			}
			if(Field07 ==="" || Field07 === undefined){
				str1 += "Field07" + ",";
			}
			if(Field08 ==="" || Field08 === undefined){
				str1 += "Field08" + ",";
			}
			
			if(Field09 ==="" || Field09 === undefined){
				str1 += "Field09" + ",";
				
			}
			if(Field10 ==="" || Field10 === undefined){
				str1 += "Field10";
			
			}*/
			//	var siteIdsSelected = this.byId("siteIdDropdownMasterList").getSelectedKey();

			var dateFields = ["CreatedDate", "EffectiveDate", "ExpirationDate", "NxtReviewDate", "ReleaseDate"];
			var filters = oBindingParams.filters;
			if (filters.length === 1) {
				var sPath = filters["0"].sPath;
				if (dateFields.indexOf(sPath) !== -1) {
					var dateField = filters["0"];
					dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
					dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
				}
			} else {
				if (filters.length > 1) {

					for (var i = 0; i < filters.length; i++) {
						sPath = filters[i].sPath;
						if (dateFields.indexOf(sPath) !== -1) {
							dateField = filters[i];
							dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
							dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
						}
					}
				}
			}

			var siteIdFilter = new sap.ui.model.Filter("SiteId", "EQ", selectedSite);
			oBindingParams.filters.push(siteIdFilter);

			//	this.filter.push(typeIdFilter);

		},
		onBeforeRebindTableControlCopies: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");

			var dateFields = ["CreatedDate", "ReleaseDate"];
			var filters = oBindingParams.filters;
			if (filters.length === 1) {
				var sPath = filters["0"].sPath;
				if (dateFields.indexOf(sPath) !== -1) {
					var dateField = filters["0"];
					dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
					dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
				}
			} else {
				if (filters.length > 1) {

					for (var i = 0; i < filters.length; i++) {
						sPath = filters[i].sPath;
						if (dateFields.indexOf(sPath) !== -1) {
							dateField = filters[i];
							dateField.oValue1 = formatter.oDataDateTimeFormatter(dateField.oValue1);
							dateField.oValue2 = formatter.oDataDateTimeFormatter(dateField.oValue2);
						}
					}
				}
			}

			var selectedSites = this.byId("siteIdDropdownControlledCopies").getSelectedKey();

			if (selectedSites.length === 0) {
				this.byId("siteIdDropdownControlledCopies").setValueState("Error");
			} else {
				this.byId("siteIdDropdownControlledCopies").setValueState("None");
				var siteIdsSelected = this.byId("siteIdDropdownControlledCopies").getSelectedKey();

				var typeIdFilter = new sap.ui.model.Filter("SiteId", "EQ", siteIdsSelected);
				oBindingParams.filters.push(typeIdFilter);
				//	this.filter.push(typeIdFilter);
			}

		},
		onBeforeRebindTableLinkedDocs: function(oEvent) {
			var oBindingParams = oEvent.getParameter("bindingParams");

			var selectedSites = this.byId("siteIdDropdownLinkedDocs").getSelectedKey();

			if (selectedSites.length === 0) {
				this.byId("siteIdDropdownLinkedDocs").setValueState("Error");
			} else {
				this.byId("siteIdDropdownLinkedDocs").setValueState("None");
				var siteIdsSelected = this.byId("siteIdDropdownLinkedDocs").getSelectedKey();

				var siteIdFilter = new sap.ui.model.Filter("SiteId", "EQ", siteIdsSelected);
				oBindingParams.filters.push(siteIdFilter);
				//	this.filter.push(typeIdFilter);

			}

			var docNumTokens = this.byId("docNumberDropDown").getSelectedItems();

			var docNumKeys = this.byId("docNumberDropDown").getSelectedKeys();
			if (docNumTokens.length > 0) {
				for (var j = 0; j < docNumKeys.length; j++) {
					if (docNumKeys[j] !== "") {
						var docNumberFilter = new sap.ui.model.Filter("JdocNumber", "EQ", docNumKeys[j]);
						oBindingParams.filters.push(docNumberFilter);
						//oBindingParams.filters.push(docNumberFilter);
					}
				}
			}

		},
		onDocsControlledCopies: function(oEvent) {

			var that = this;
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				id: "ccValueHelpDialog",
				busyIndicatorDelay: 0,
				title: that.getView().getModel("i18n").getResourceBundle().getText("ccValueHelpTitle"),
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "JdocNumber",
				descriptionKey: "JdocRevision",
				stretch: sap.ui.Device.system.phone,
				draggable: false,
				ok: function() {
					var selectedDocIndices = oValueHelpDialog.getTable().getSelectedIndices();
					if (selectedDocIndices.length > 0) {
						for (var i = 0; i < selectedDocIndices.length; i++) {
							var selectedData = oValueHelpDialog.getTable().getContextByIndex(selectedDocIndices[i]);
							var sPath = selectedData.sPath;
							var docData = selectedData.getModel().oData[sPath.slice(1)];

							if (that.byId("docsControlledCopies").getTokens().length > 0) {
								that.byId("docsControlledCopies").addToken(new sap.m.Token({
									text: docData.JdocNumber
								}));
							} else {
								that.byId("docsControlledCopies").setTokens([new sap.m.Token({
									text: docData.JdocNumber
								})]);
							}
							that.byId("docsControlledCopies").setValue("");
						}
					}
					/**/
					//	that.onSupplierSelection(supplierData);

					oValueHelpDialog.close();
				},
				cancel: function() {
					oValueHelpDialog.close();
				},
				afterClose: function() {
					oValueHelpDialog.destroy();
				},
				afterOpen: function() {
					that.onSetValueHelpData("ccValueHelpDialog", "SrchHelpCCDocSet", "", "");
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: that.getView().getModel("i18n").getResourceBundle().getText("jdocNumberColumn"),
					template: "JdocNumber"
				}, {
					label: that.getView().getModel("i18n").getResourceBundle().getText("jdocRevisionColumn"),
					template: "JdocRevision"
				}]
			});

			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showClearOnFB: true,
				clear: [this.onClearSmartFilter, this],
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function() {
					//	var siteId = that.byId("siteDropdown").getSelectedKey();
					//	var filters = new sap.ui.model.Filter("SiteId", "EQ", siteId);
					var filtersArray = [];
					//	filtersArray.push(filters);
					var searchString1 = sap.ui.getCore().byId("ccValueBasicSearch").getValue();
					that.onSetValueHelpData("ccValueHelpDialog", "SrchHelpCCDocSet", encodeURI(searchString1), "");
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "ccValueBasicSearch",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function() {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);
			this.getView().addDependent(oValueHelpDialog);
			oValueHelpDialog.open();

		},
		onSetValueHelpData: function(id, oEntitySet, oSearchString, filtersArray) {
			var oValueHelpDialog = sap.ui.getCore().byId(id);
			if (oValueHelpDialog !== undefined) {
				oValueHelpDialog.getTable().bindRows({
					path: "/" + oEntitySet,
					parameters: {
						custom: {
							search: oSearchString
						}
					},
					filters: filtersArray
				});

				oValueHelpDialog.getTable().rerender();

				if (oValueHelpDialog.getTable().bindItems) {
					var oTable = oValueHelpDialog.getTable();
					oTable.bindAggregation("items", "/", function(sId, oContext) {
						var aCols = oTable.getModel("columns").getData().cols;
						return new sap.m.ColumnListItem({
							cells: aCols.map(function(column) {
								var colname = column.template;
								return new sap.m.Label({
									text: "{" + colname + "}"
								});
							})
						});
					});
				}
			}
		},

		onSiteChange: function(oEvent) {
			var selectedDocType = oEvent.getSource().getSelectedKeys();
			if (selectedDocType.length > 0) {
				oEvent.getSource().setValueState("None");
			} else {
				oEvent.getSource().setValueState("Error");
			}
		},
		onSiteChangeMasterList: function(oEvent) {
			var that = this;
			var selectedSite = oEvent.getSource().getSelectedKey();

			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);

			var oFilter1 = new sap.ui.model.Filter("SiteId", "EQ", selectedSite);
			oModelVariantO1.read("SrchHelpLinkedJdocsSet", {
				filters: [oFilter1],
				success: function(data2) {
					var oModel2 = new JSONModel();
					oModel2.setData(data2);

					that.getView().setModel(oModel2, "docNumberModel");
					//	that.byId("docNumberDropDown").setSelectedKeys(oModel2.getData().results[0].TypeId);
				}
			}, this);

			/*	if (selectedDocType.length > 0) {
					oEvent.getSource().setValueState("None");
				} else {
					oEvent.getSource().setValueState("Error");
				}*/
		},
		/*onMasterListDataRecieved:function(oEvent){
				var column = this.byId("responsiveTableInProcessChart").getColumns()[3];
			this.getView().byId("responsiveTableInProcessChart").filter(column, this.selectedInProcessSector);
			column.setFilterValue(this.selectedInProcessSector);
		},*/
		onSectorSelectInProcess: function(oEvent) {

			

			this.selectedInProcessSector = oEvent.getParameter("data")[0].data.TaskType;

			var that = this;
			if (!this._oTableInProcessChart) {
				this._oTableInProcessChart = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.TableInProcessChart", this);
				this.getView().addDependent(this._oTableInProcessChart);
			}

			this.byId("siteIdDropdown").setModel(this.jsonModelForSite, "siteModel");
				
			if (this.arraySiteInProcess.length > 0) {
				this.byId("siteIdDropdown").setSelectedKeys(this.arraySiteInProcess);
			} else {
				this.byId("siteIdDropdown").setSelectedKeys(this.localInitialSite);
			}

			this.byId("typeIdDropdown").setModel(this.localJsonModelForInProcessDocTypeDropdown, "docTypeModel");
			this.byId("typeIdDropdown").setSelectedKeys(this.arrayDocTypeInProcess);

			this.byId("customerIdDropDown").setModel(this.localJsonModelForInProcessCustomersDropdown, "customerModel");
			this.byId("customerIdDropDown").setSelectedKeys(this.arrayCustomerInProcess);

			this.byId("deptIdDropDown").setModel(this.localJsonModelForInProcessDeptDropdown, "deptModel");
			this.byId("deptIdDropDown").setSelectedKeys(this.arrayDeptInProcess);

			this.byId('statusDropDown').setModel(this.localJsonModelForInProcessStatusDropdown, "statusModel");
			this.byId("statusDropDown").setSelectedKeys(this.arrayStatusInProcess);

			this.byId("pendingUserDropDown").setModel(this.localJsonModelForInProcessPendingUsersDropdown, "pendingUserModel");
			this.byId("pendingUserDropDown").setSelectedKeys(this.arrayUserInProcess);
				

			
			//To set Predefined value based on sector Select
				// var selectedSector = oEvent.getParameter("data")[0].data.Status; 
				// var column = this.byId("responsiveTableInProcessChart").getColumns()[1];
				// this.getView().byId("responsiveTableInProcessChart").filter("Department", "BU");
				// column.setFilterValue("00-0110-00001");
			
		
			
			this._oTableInProcessChart.open();
			/*	this.byId("smartFilterBarInProcessChart").mAggregations.controlConfiguration["0"].mAggregations.defaultFilterValues["0"].mProperties
					.low = this.localInitialSite;*/

		},
		onSectorSelectDocStatus: function(oEvent) {
			this.selectedDocStatusSector = oEvent.getParameter("data")[0].data.Status;
			var that = this;
			if (!this._oSectorSelectDocStatus) {
				this._oSectorSelectDocStatus = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.TableDocStatusChart", this);
				this.getView().addDependent(this._oSectorSelectDocStatus);
			}
			this.byId("siteIdDropdownDocStatus").setModel(this.jsonModelForSite, "siteModel");
			if (this.arraySiteDocumentStatus.length > 0) {
				this.byId("siteIdDropdownDocStatus").setSelectedKeys(this.arraySiteDocumentStatus);
			} else {
				this.byId("siteIdDropdownDocStatus").setSelectedKeys(this.localInitialSite);
			}
			this.byId("typeIdDropdownDocStatus").setModel(this.localJsonModelForInProcessDocTypeDropdown, "docTypeModel");
			this.byId("typeIdDropdownDocStatus").setSelectedKeys(this.arrayDocTypeDropDocumentStatus);

			this.byId("customerIdDropDownDocStatus").setModel(this.localJsonModelForInProcessCustomersDropdown, "customerModel");
			this.byId("customerIdDropDownDocStatus").setSelectedKeys(this.arrayCustomerDropDocumentStatus);

			this.byId("authorIdDropDownDocStatus").setModel(this.localJsonModelForDocStatusAuthorDropdown, "authorModel");
			this.byId("authorIdDropDownDocStatus").setSelectedKeys(this.arrayAuthorOwnerDrop);

			this.byId("ownerIdDropDownDocStatus").setModel(this.localJsonModelForDocStatusAuthorDropdown1, "ownerModel");
			this.byId("ownerIdDropDownDocStatus").setSelectedKeys(this.arrayAuthorOwnerDrop1);

			//	this.byId("siteIdDropdownDocStatus").setSelectedKeys(this.localInitialSite);
			this._oSectorSelectDocStatus.open();

			/*this.byId("smartFilterBarDocStatus").mAggregations.controlConfiguration["0"].mAggregations.defaultFilterValues["0"].mProperties.low =
				this.localInitialSite;*/
		},
		onSectorSelectDocType: function(oEvent) {
			//MTest-JDoc360-App-Issue#97
			
			//this.selectedDocTypeSector = oEvent.getParameter("data")[0].data.Type;
			this.selectedDocTypeSector = oEvent.getParameter("data")[0].data.Type.split("~")[0];
			this.selectedDocSubTypeSector = oEvent.getParameter("data")[0].data.Type.split("~")[1];
			this.selectedDocTypeDesSector = oEvent.getParameter("data")[0].data.Type.split("~")[2];
			var that = this;
			if (!this._oSectorSelectDocType) {
				this._oSectorSelectDocType = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.TableDocTypeChart", this);
				this.getView().addDependent(this._oSectorSelectDocType);
			}
			this.byId("siteIdDropdownDocType").setModel(this.jsonModelForSite, "siteModel");

			if (this.arraySiteDocumentTypes.length > 0) {
				this.byId("siteIdDropdownDocType").setSelectedKeys(this.arraySiteDocumentTypes);
			} else {
				this.byId("siteIdDropdownDocType").setSelectedKeys(this.localInitialSite);
			}

			this.byId("customerIdDropDownDocType").setModel(this.localJsonModelForInProcessCustomersDropdown, "customerModel");
			this.byId("customerIdDropDownDocType").setSelectedKeys(this.arrayCustomerDocumentTypes);

			this.byId("statusIdDropDownDocType").setModel(this.localJsonModelForDocumentTypesStatusDropdown, "statusModel");
			this.byId("statusIdDropDownDocType").setSelectedKeys(this.arrayStatusDocumentTypes);

			this.byId("authorIdDropDownDocType").setModel(this.localJsonModelForDocStatusAuthorDropdown, "authorModel");
			this.byId("authorIdDropDownDocType").setSelectedKeys(this.arrayAuthorOwnerDocumentTypes);

			this.byId("ownerIdDropDownDocType").setModel(this.localJsonModelForDocStatusAuthorDropdown1, "ownerModel");
			this.byId("ownerIdDropDownDocType").setSelectedKeys(this.arrayAuthorOwnerDocumentTypes1);

			//	this.byId("siteIdDropdownDocType").setSelectedKeys(this.localInitialSite);
			this._oSectorSelectDocType.open();
			/*this.byId("smartFilterBarDocType").mAggregations.controlConfiguration["0"].mAggregations.defaultFilterValues["0"].mProperties.low =
				this.localInitialSite;*/
		},
		onSectorSelectPeriodicReview: function(oEvent) {
			this.selectedPeriodicReviewSector = oEvent.getParameter("data")[0].data.Status;
			var that = this;
			if (!this._oSectorSelectPeriodicReview) {
				this._oSectorSelectPeriodicReview = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.TablePeriodicReview", this);
				this.getView().addDependent(this._oSectorSelectPeriodicReview);
			}
			this.byId("siteIdDropdownPeriodicReview").setModel(this.jsonModelForSite, "siteModel");
			if (this.arraySitePeriodicReview.length > 0) {
				this.byId("siteIdDropdownPeriodicReview").setSelectedKeys(this.arraySitePeriodicReview);
			} else {
				this.byId("siteIdDropdownPeriodicReview").setSelectedKeys(this.localInitialSite);
			}

			this.byId("typeIdDropdownPeriodicReview").setModel(this.localJsonModelForInProcessDocTypeDropdown, "docTypeModel");
			this.byId("typeIdDropdownPeriodicReview").setSelectedKeys(this.arrayDocTypePeriodicReview);

			this.byId("customerIdDropDownPeriodicReview").setModel(this.localJsonModelForInProcessCustomersDropdown, "customerModel");
			this.byId("customerIdDropDownPeriodicReview").setSelectedKeys(this.arrayCustomerPeriodicReview);

			this.byId("deptIdDropDownPeriodicReview").setModel(this.localJsonModelForInProcessDeptDropdown, "deptModel");
			this.byId("deptIdDropDownPeriodicReview").setSelectedKeys(this.arrayDeptPeriodicReview);

			this.byId("authorIdDropDownPeriodicReview").setModel(this.localJsonModelForDocStatusAuthorDropdown, "authorModel");
			this.byId("authorIdDropDownPeriodicReview").setSelectedKeys(this.arrayAuthorOwnerPeriodicReview);

			this.byId("ownerIdDropDownPeriodicReview").setModel(this.localJsonModelForDocStatusAuthorDropdown1, "ownerModel");
			this.byId("ownerIdDropDownPeriodicReview").setSelectedKeys(this.arrayAuthorOwnerPeriodicReview1);

			this.byId("pendingUserDropDownPeriodicReview").setModel(this.localJsonModelForInProcessPendingUsersDropdown, "pendingUserModel");
			this.byId("pendingUserDropDownPeriodicReview").setSelectedKeys(this.arrayUserPeriodicReview);

			this._oSectorSelectPeriodicReview.open();
		},
		gapAssessmentReport: function(oEvent) {
			if (!this._oGapAssessmentReport) {
				this._oGapAssessmentReport = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.GapAssessmentReport", this);
				this.getView().addDependent(this._oGapAssessmentReport);
			}
			this._oGapAssessmentReport.open();
		},
		cancelGapAssessmentReport: function() {
			this._oGapAssessmentReport.close();
			this._oGapAssessmentReport.destroy();
			this._oGapAssessmentReport = undefined;
		},
		openErrorHandling: function(evt) {
			
			
			if (!this._oResetPasswordDialog) {
				this._oResetPasswordDialog = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.ErrorHandlingFilter", this);
				this.getView().addDependent(this._oResetPasswordDialog);
			}
			this._oResetPasswordDialog.open();
			this.byId("idonexporterrorlog").setEnabled(false);
			var that = this;
			sap.ui.core.BusyIndicator.show(0);
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			var oFilter1 = new sap.ui.model.Filter("JdocNumber", "EQ", "*");

			oModelVariantO1.read("SrchHelpErrLogSitesSet", {

				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();
					//	console.log(oData);

					var siteDropDown = that.byId("siteId");
					var siteModel = new JSONModel();
					siteModel.setData(oData);
					//	siteDropDown.setModel(new JSONModel(null), "tabModel");
					//	siteDropDown.getModel("tabModel").setSizeLimit(oData.results.length);
					siteDropDown.setModel(siteModel, "siteModel");
					//	siteDropDown.setModel("tabModel").setData(oData);

				},

				error: function(err) {
					//		alert("Service Failed");
					sap.ui.core.BusyIndicator.hide();
				}
			});

			//	var oJsonModelErrorLog = new sap.ui.model.json.JSONModel();
			oModelVariantO1.read("SrchHelpJdocNumRevSet", {
				filters: [oFilter1],

				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();
					//	console.log(oData);

					/*var oTable = that.getView().byId("jdocNumber");
					oTable.setModel(new JSONModel(null), "tabModel");
					oTable.getModel("tabModel").setSizeLimit(oData.results.length);

					oTable.getModel("tabModel").setData(oData);
					oTable.getModel("tabModel").setSizeLimit(oData.results.length);
					oTable.getModel("tabModel").refresh();*/
				},

				error: function(err) {
					//		alert("Service Failed");
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		onSiteChangeErrorLog: function(oEvent) {
			var that = this;
			var selectedSite = oEvent.getSource().getSelectedKey();
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			var oFilter1 = new sap.ui.model.Filter("SiteId", "EQ", selectedSite);

			oModelVariantO1.read("SrchHelpErrorLogUsersSet", {
				filters: [oFilter1],

				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();

					var userModel = new JSONModel();
					userModel.setData(oData);
					that.byId("userId").setModel(userModel, "userModel");

				},

				error: function(err) {
					//		alert("Service Failed");
					sap.ui.core.BusyIndicator.hide();
				}
			});

		},
		onValueHelpUserId: function(oEvent) {
			var that = this;
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				id: "userIdValueHelpDialog",
				busyIndicatorDelay: 0,
				title: that.getView().getModel("i18n").getResourceBundle().getText("userIdValueHelpTitle"),
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				key: "UserId",
				descriptionKey: "UserId",
				stretch: sap.ui.Device.system.phone,
				draggable: false,
				ok: function() {
					var selectedAuthorIndices = oValueHelpDialog.getTable().getSelectedIndex();

					var selectedData = oValueHelpDialog.getTable().getContextByIndex(selectedAuthorIndices);
					var sPath = selectedData.sPath;
					var supplierData = selectedData.getModel().oData[sPath.slice(1)];

					that.byId("userId").setTokens([new sap.m.Token({
						text: supplierData.UserId
					})]);

					that.byId("userId").setValue("");
					oValueHelpDialog.close();

					/**/
					//	that.onSupplierSelection(supplierData);

				},
				cancel: function() {
					oValueHelpDialog.close();
				},
				afterClose: function() {
					oValueHelpDialog.destroy();
				},
				afterOpen: function() {
					that.onSetValueHelpData("userIdValueHelpDialog", "SrchHelpErrorLogUsersSet", "", "");
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: that.getView().getModel("i18n").getResourceBundle().getText("userId"),
					template: "UserId"
				}, {
					label: that.getView().getModel("i18n").getResourceBundle().getText("userFirstName"),
					template: "FirstName"
				}, {
					label: that.getView().getModel("i18n").getResourceBundle().getText("userLastName"),
					template: "LastName"
				}]
			});

			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showClearOnFB: true,
				clear: [this.onClearSmartFilter, this],
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function() {
					var siteId = that.byId("siteId").getSelectedKey();
					var filters = new sap.ui.model.Filter("SiteId", "EQ", siteId);
					var filtersArray = [];
					filtersArray.push(filters);
					var searchString1 = sap.ui.getCore().byId("userValueBasicSearch").getValue();
					that.onSetValueHelpData("userIdValueHelpDialog", "SrchHelpErrorLogUsersSet", encodeURI(searchString1), filtersArray);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "userValueBasicSearch",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function() {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);
			this.getView().addDependent(oValueHelpDialog);
			oValueHelpDialog.open();
		},
		handleSuggestUserId: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var siteId = this.byId("siteId").getSelectedKey();
			var aFilters = [];
			var filter1 = new sap.ui.model.Filter("SiteId", "EQ", siteId);
			aFilters.push(filter1);
			if (sTerm) {
				oEvent.getSource().getBinding("suggestionRows").sCustomParams = "search=" + sTerm;
			}
			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);

		},
		onUserIdSelect: function(oEvent) {
			var userIdSelected = oEvent.getParameter("selectedRow").getBindingContext().getProperty("UserId");

			this.byId("userId").setTokens([new sap.m.Token({
				text: userIdSelected
			})]);

			this.byId("userId").setValue("");
		},
		onValueHelpJdocNo: function(oEvent) {
			var that = this;
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				id: "jdocValueHelpDialog",
				busyIndicatorDelay: 0,
				title: that.getView().getModel("i18n").getResourceBundle().getText("jdocValueHelpTitle"),
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				key: "JdocNumber",
				descriptionKey: "JdocNumber",
				stretch: sap.ui.Device.system.phone,
				draggable: false,
				ok: function() {
					var selectedAuthorIndices = oValueHelpDialog.getTable().getSelectedIndex();

					var selectedData = oValueHelpDialog.getTable().getContextByIndex(selectedAuthorIndices);
					var sPath = selectedData.sPath;
					var supplierData = selectedData.getModel().oData[sPath.slice(1)];

					that.byId("jdocNumber").setTokens([new sap.m.Token({
						text: supplierData.JdocNumber
					})]);

					that.byId("jdocNumber").setValue("");
					oValueHelpDialog.close();

					/**/
					//	that.onSupplierSelection(supplierData);

				},
				cancel: function() {
					oValueHelpDialog.close();
				},
				afterClose: function() {
					oValueHelpDialog.destroy();
				},
				afterOpen: function() {
					that.onSetValueHelpData("jdocValueHelpDialog", "SrchHelpJdocNumRevSet", "", "");
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: that.getView().getModel("i18n").getResourceBundle().getText("jdocNumberHeader"),
					template: "JdocNumber"
				}, {
					label: that.getView().getModel("i18n").getResourceBundle().getText("jdocRevisionHeader"),
					template: "JdocRevision"
				}]
			});

			oValueHelpDialog.getTable().setModel(oColModel, "columns");
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showClearOnFB: true,
				clear: [this.onClearSmartFilter, this],
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function() {
					/*var siteId = that.byId("jdocNumber").getSelectedKey();
					var filters = new sap.ui.model.Filter("SiteId", "EQ", siteId);*/
					var filtersArray = [];
					//	filtersArray.push(filters);
					var searchString1 = sap.ui.getCore().byId("jdocValueBasicSearch").getValue();
					that.onSetValueHelpData("jdocValueHelpDialog", "SrchHelpJdocNumRevSet", encodeURI(searchString1), filtersArray);
				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					id: "jdocValueBasicSearch",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function() {
						oValueHelpDialog.getFilterBar().search();
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);
			this.getView().addDependent(oValueHelpDialog);
			oValueHelpDialog.open();
		},
		handleSuggestJdocNo: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			//	var siteId = this.byId("siteId").getSelectedKey();
			var aFilters = [];
			//	var filter1 = new sap.ui.model.Filter("SiteId", "EQ", siteId);
			//	aFilters.push(filter1);
			if (sTerm) {
				oEvent.getSource().getBinding("suggestionRows").sCustomParams = "search=" + sTerm;
			}
			oEvent.getSource().getBinding("suggestionRows").filter(aFilters);

		},
		onJdocNoSelect: function(oEvent) {
			var userIdSelected = oEvent.getParameter("selectedRow").getBindingContext().getProperty("JdocNumber");

			this.byId("jdocNumber").setTokens([new sap.m.Token({
				text: userIdSelected
			})]);

			this.byId("jdocNumber").setValue("");
		},
	
		masterListReportDataRecieved: function(oEvent) {
		
		 var str = []; 
		str = this.getView().getModel("labelModel").oData.results;
		
		 this.byId("smartTableMasterList").setIgnoreFromPersonalisation("Field09,Field10");	
		},
		cancelMasterListReport: function() {
			this._oMasterListReport.close();
			this._oMasterListReport.destroy();
			this._oMasterListReport = undefined;

		},
		dowloadChart1: function() {
			var vizFrame = this.getView().byId("idpiechart2");
			this.downloadAsImage(vizFrame, "In Process Documents");
		},
		dowloadChart2: function() {
			var vizFrame = this.getView().byId("idpiechart3");
			this.downloadAsImage(vizFrame, "Document Status");
		},
		dowloadChart3: function() {
			var vizFrame = this.getView().byId("idpiechart33");
			this.downloadAsImage(vizFrame, "Document Types");
		},
		dowloadChart4: function() {
			var vizFrame = this.getView().byId("idpiechart4");
			this.downloadAsImage(vizFrame, "Periodic Review");
		},
	
		downloadAsImage: function(vizFrame, status) {
			var svg = vizFrame.getDomRef().getElementsByTagName("svg")[0];
			//var xml;
			var canvas = document.createElement("canvas");

			//	var c = document.createElement('canvas');
			/*canvas.width = svg.clientWidth;
			canvas.height = svg.clientHeight;
			svg.parentNode.insertBefore(canvas, svg);
			svg.parentNode.removeChild(svg);
			var div = document.createElement('div');
			div.appendChild(svg);
			canvg(canvas, div.innerHTML);*/

			/*	var outer = document.createElement('div');
				outer.appendChild(svg.cloneNode(true));
				return outer.innerHTML;

				var dom = vizFrame.getDomRef();

				var used = "";
				var sheets = document.styleSheets;
				for (var i = 0; i < sheets.length; i++) {
					var rules = sheets[i].cssRules;
					for (var j = 0; j < rules.length; j++) {
						var rule = rules[j];
						if (typeof(rule.style) != "undefined") {
							var elems = dom.querySelectorAll(rule.selectorText);
							if (elems.length > 0) {
								used += rule.selectorText + " { " + rule.style.cssText + " }\n";
							}
						}
					}
				}

				var s = document.createElement('style');
				s.setAttribute('type', 'text/css');
				s.innerHTML = "<![CDATA[\n" + used + "\n]]>";

				var defs = document.createElement('defs');
				defs.appendChild(s);
				dom.insertBefore(defs, dom.firstChild);*/

			/*--------------------------------------------------------------------*/
			/*	canvas.width = svg.clientWidth || 500;
				canvas.height = svg.clientWidth || 500;
				svg.innerHTML = '';
				svg.appendChild(canvas);
				if (typeof FlashCanvas != "undefined") {
					FlashCanvas.initElement(canvas);
				}*/

			//	canvg(canvas, '<svg class="v-m-root" focusable="false" tabIndex="-1" style="left: 0 px; top: 0 px; height: 100 % ; width: 100 % ; display: block; cursor: default;"><canvas width="305 " height="305 "></canvas></svg>"');
			//canvg(canvas, "http://www.w3.org/2000/svg")
			/*canvg(canvas, 'file.svg', {
				ignoreMouse: true,
				ignoreAnimation: true
			});*/

			/*-----------------------------------------------------*/

			/*ONE MORE METHOD-----------------------*/

			//	var canvas = document.createElement("canvas"),
			/*var cctx = canvas.getContext("2d");
			var rawSvg = new XMLSerializer().serializeToString(svg.node());
			canvas.width = svg.clientWidth;
			canvas.height = svg.clientWidth;*/
			//cctx.drawImage(this, 0, 0);
			//-- Use Canvg's extension to canvasContext
			//	cctx.drawSvg(rawSvg);
			//-- This Works on IE - not accurate though
			//	var dataURL = canvas.toDataURL();
			//	canvg(canvas, dataURL);
			/*------------------------------------*/

			canvas.setAttribute("width", svg.clientWidth);
			canvas.setAttribute("height", svg.clientHeight);
			var context = canvas.getContext("2d");
			var imageObj = new Image();
			
			imageObj.onload = function() {
				context.drawImage(imageObj, 0, 0);
				var a = document.createElement('a');
				if (status === "In Process Documents") {
					a.setAttribute("download", "In_Process_Documents.jpeg");
				} else if (status === "Document Status") {
					a.setAttribute("download", "Document_Status.jpeg");
				} else if (status === "Document Types") {
					a.setAttribute("download", "Document_Types.jpeg");
				} else {
					a.setAttribute("download", "Periodic_Review.jpeg");
				}
				a.setAttribute("href", canvas.toDataURL());
				a.click();

				/*	canvg('canvas', '../path/to/your.svg');

					//load a svg snippet in the canvas with id = 'drawingArea'
					canvg(document.getElementById('drawingArea'), '<svg>...</svg>');

					//ignore mouse events and animation
					canvg('canvas', 'file.svg', {
						ignoreMouse: true,
						ignoreAnimation: true
					});*/

			};
			imageObj.width = svg.clientWidth;
			imageObj.height = svg.clientHeight;

			imageObj.src = "data:image/svg+xml," + jQuery.sap.encodeURL(svg.outerHTML.replace(/^<svg/, "<svg xmlns='http://www.w3.org/2000/svg' version='1.1'"));
			
			//MTest-JDOC360-App-Issue#255
			
			//	$('<div>').append($(svg).clone()).html();
			
		
			
			//	canvas.className = "screenShotTempCanvas";
			//convert SVG into a XML string
			//	xml = (new sap.ui.core.util.serializer.XMLViewSerializer()).serializeToString(this);

			// Removing the name space as IE throws an error
			//	xml = xml.replace(/xmlns=\"http:\/\/www\.w3\.org\/2000\/svg\"/, '');

			//draw the SVG onto a canvas
			//		canvg(canvas, xml);
			//	$(canvas).insertAfter(this);
			//hide the SVG element
			//	this.className = "tempHide";
			//	$(this).hide();

		},
		attachPersonalizationPressDocumentTypes: function(oEvent) {

			if (!this._filtersForDocumentTypes) {
				this._filtersForDocumentTypes = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.FiltersDocumentTypes", this);
				this.getView().addDependent(this._filtersForDocumentTypes);
			}
			this._filtersForDocumentTypes.open();
			this.byId("siteDocumentTypes").setModel(this.localJsonModelForInProcessSiteDropdown);
			//	this.byId("siteDocumentTypes").setSelectedKeys(this.localInitialSite);
			if (this.arraySiteDocumentTypes.length > 0) {
				this.byId("siteDocumentTypes").setSelectedKeys(this.arraySiteDocumentTypes);

			} else {
				this.byId("siteDocumentTypes").setSelectedKeys(this.localInitialSite);
			}
			this.byId("authorDocumentTypes").setModel(this.localJsonModelForDocStatusAuthorDropdown);
			if (this.arrayAuthorOwnerDocumentTypes.length > 0) {
				this.byId("authorDocumentTypes").setSelectedKeys(this.arrayAuthorOwnerDocumentTypes);

			}
			this.byId("ownerDocumentTypes").setModel(this.localJsonModelForDocStatusAuthorDropdown1);
			if (this.arrayAuthorOwnerDocumentTypes1.length > 0) {
				this.byId("ownerDocumentTypes").setSelectedKeys(this.arrayAuthorOwnerDocumentTypes1);

			}
			this.byId("customerDocumentTypes").setModel(this.localJsonModelForInProcessCustomersDropdown);
			if (this.arrayCustomerDocumentTypes.length > 0) {
				this.byId("customerDocumentTypes").setSelectedKeys(this.arrayCustomerDocumentTypes);

			}
			this.byId("statusDocumentTypes").setModel(this.localJsonModelForDocumentTypesStatusDropdown);
			if (this.arrayStatusDocumentTypes.length > 0) {
				this.byId("statusDocumentTypes").setSelectedKeys(this.arrayStatusDocumentTypes);

			}
			this.byId("docTypeDrop").setModel(this.localJsonModelForInProcessDocTypeDropdown);
			if (this.arraydocumentTypes.length > 0) {
				this.byId("docTypeDrop").setSelectedKeys(this.arraydocumentTypes);

			}
			
			
			this.changeSiteDocumentTypes(oEvent);
		},
		attachPersonalizationPressPeriodicReview: function(oEvent) {

			if (!this._filtersForPeriodicReview) {
				this._filtersForPeriodicReview = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.FiltersPeriodicReview", this);
				this.getView().addDependent(this._filtersForPeriodicReview);
			}
			this._filtersForPeriodicReview.open();
			this.byId("sitePeriodicReview").setModel(this.localJsonModelForInProcessSiteDropdown);
			if (this.arraySitePeriodicReview.length > 0) {
				this.byId("sitePeriodicReview").setSelectedKeys(this.arraySitePeriodicReview);

			} else {
				this.byId("sitePeriodicReview").setSelectedKeys(this.localInitialSite);
			}

			//	this.byId("sitePeriodicReview").setSelectedKeys(this.localInitialSite);
			this.byId("deptPeriodicReview").setModel(this.localJsonModelForInProcessDeptDropdown);
			if (this.arrayDeptPeriodicReview.length > 0) {
				this.byId("deptPeriodicReview").setSelectedKeys(this.arrayDeptPeriodicReview);

			}
			this.byId("authorPeriodicReview").setModel(this.localJsonModelForDocStatusAuthorDropdown);
			if (this.arrayAuthorOwnerPeriodicReview.length > 0) {
				this.byId("authorPeriodicReview").setSelectedKeys(this.arrayAuthorOwnerPeriodicReview);

			}
			this.byId("ownerPeriodicReview").setModel(this.localJsonModelForDocStatusAuthorDropdown1);
			if (this.arrayAuthorOwnerPeriodicReview1.length > 0) {
				this.byId("ownerPeriodicReview").setSelectedKeys(this.arrayAuthorOwnerPeriodicReview1);

			}
			this.byId("docTypePeriodicReview").setModel(this.localJsonModelForInProcessDocTypeDropdown);
			if (this.arrayDocTypePeriodicReview.length > 0) {
				this.byId("docTypePeriodicReview").setSelectedKeys(this.arrayDocTypePeriodicReview);

			}
			this.byId("customerPeriodicReview").setModel(this.localJsonModelForInProcessCustomersDropdown);
			if (this.arrayCustomerPeriodicReview.length > 0) {
				this.byId("customerPeriodicReview").setSelectedKeys(this.arrayCustomerPeriodicReview);

			}
			this.byId("userPeriodicReview").setModel(this.localJsonModelForInProcessPendingUsersDropdown);
			if (this.arrayUserPeriodicReview.length > 0) {
				this.byId("userPeriodicReview").setSelectedKeys(this.arrayUserPeriodicReview);

			}
			this.changeSitePeriodicReview(oEvent);

		},
		attachPersonalizationPressDocStatus: function(oEvent) {

			if (!this._filtersForDocStatusChart) {
				this._filtersForDocStatusChart = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.FiltersDocumentStatus", this);
				this.getView().addDependent(this._filtersForDocStatusChart);
			}
			this._filtersForDocStatusChart.open();
			this.byId("siteDocumentStatus").setModel(this.localJsonModelForInProcessSiteDropdown);

			if (this.arraySiteDocumentStatus.length > 0) {
				this.byId("siteDocumentStatus").setSelectedKeys(this.arraySiteDocumentStatus);

			} else {
				this.byId("siteDocumentStatus").setSelectedKeys(this.localInitialSite);
			}

			/*	this.byId("siteInProcess").setModel(this.localJsonModelForInProcessSiteDropdown);
				this.byId("siteInProcess").setSelectedKeys(this.localInitialSite);
				this.byId("docTypeDrop").setModel(this.localJsonModelForInProcessDocTypeDropdown);
				this.byId("deptDrop").setModel(this.localJsonModelForInProcessDeptDropdown);
				this.byId('statusDrop').setModel(this.localJsonModelForInProcessStatusDropdown);
				this.byId("UserDrop").setModel(this.localJsonModelForInProcessPendingUsersDropdown);
				this.byId("CustomerDrop").setModel(this.localJsonModelForInProcessCustomersDropdown);
			*/ //

			this.byId("authorDrop").setModel(this.localJsonModelForDocStatusAuthorDropdown);
			if (this.arrayAuthorOwnerDrop.length > 0) {
				this.byId("authorDrop").setSelectedKeys(this.arrayAuthorOwnerDrop);

			}
			this.byId("ownerDrop").setModel(this.localJsonModelForDocStatusAuthorDropdown1);
			if (this.arrayAuthorOwnerDrop1.length > 0) {
				this.byId("ownerDrop").setSelectedKeys(this.arrayAuthorOwnerDrop1);

			}
			this.byId("docTypeDropDocumentStatus").setModel(this.localJsonModelForInProcessDocTypeDropdown);
			if (this.arrayDocTypeDropDocumentStatus.length > 0) {
				this.byId("docTypeDropDocumentStatus").setSelectedKeys(this.arrayDocTypeDropDocumentStatus);

			}
			this.byId("CustomerDropDocumentStatus").setModel(this.localJsonModelForInProcessCustomersDropdown);
			if (this.arrayCustomerDropDocumentStatus.length > 0) {
				this.byId("CustomerDropDocumentStatus").setSelectedKeys(this.arrayCustomerDropDocumentStatus);

			}
			this.changeSiteDocumentStatus(oEvent);

		},
		attachPersonalizationPress: function(oEvent) {
			if (!this._filtersForInProcessChart) {
				this._filtersForInProcessChart = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.FiltersInProcessTasks", this);
				this.getView().addDependent(this._filtersForInProcessChart);
			}

			this._filtersForInProcessChart.open();

			//code for setting the sites in smart table
			this.byId("siteInProcess").setModel(this.localJsonModelForInProcessSiteDropdown);
			if (this.arraySiteInProcess.length > 0) {
				this.byId("siteInProcess").setSelectedKeys(this.arraySiteInProcess);

			} else {
				this.byId("siteInProcess").setSelectedKeys(this.localInitialSite);
			}
			this.byId("docTypeDrop").setModel(this.localJsonModelForInProcessDocTypeDropdown);
			if (this.arrayDocTypeInProcess.length > 0) {
				this.byId("docTypeDrop").setSelectedKeys(this.arrayDocTypeInProcess);

			}
			this.byId("deptDrop").setModel(this.localJsonModelForInProcessDeptDropdown);
			if (this.arrayDeptInProcess.length > 0) {
				this.byId("deptDrop").setSelectedKeys(this.arrayDeptInProcess);

			}
			this.byId("statusDrop").setModel(this.localJsonModelForInProcessStatusDropdown);
			if (this.arrayStatusInProcess.length > 0) {
				this.byId("statusDrop").setSelectedKeys(this.arrayStatusInProcess);

			}
			this.byId("UserDrop").setModel(this.localJsonModelForInProcessPendingUsersDropdown);
			if (this.arrayUserInProcess.length > 0) {
				this.byId("UserDrop").setSelectedKeys(this.arrayUserInProcess);

			}
			this.byId("CustomerDrop").setModel(this.localJsonModelForInProcessCustomersDropdown);
			if (this.arrayCustomerInProcess.length > 0) {
				this.byId("CustomerDrop").setSelectedKeys(this.arrayCustomerInProcess);

			}
			this.changeSiteInProcess(oEvent);
		},
		applyFiltersPeriodicReviewCharts: function(evt) {

			this.arrayDeptPeriodicReview = this.byId("deptPeriodicReview").getSelectedKeys();
			this.arrayDocTypePeriodicReview = this.byId("docTypePeriodicReview").getSelectedKeys();
			this.arrayCustomerPeriodicReview = this.byId("customerPeriodicReview").getSelectedKeys();
			this.arrayAuthorOwnerPeriodicReview = this.byId("authorPeriodicReview").getSelectedKeys();
			this.arrayAuthorOwnerPeriodicReview1 = this.byId("ownerPeriodicReview").getSelectedKeys();
			this.arrayUserPeriodicReview = this.byId("userPeriodicReview").getSelectedKeys();
			this.arraySitePeriodicReview = this.byId("sitePeriodicReview").getSelectedKeys();

			var headerStr = "";
			for (var z = 0; z < this.byId("sitePeriodicReview").getSelectedKeys().length; z++) {
				if (z < (this.byId("sitePeriodicReview").getSelectedKeys().length - 1)) {
					headerStr += this.byId("sitePeriodicReview").getSelectedKeys()[z] + ",";
				} else {
					headerStr += this.byId("sitePeriodicReview").getSelectedKeys()[z];
				}
			}
			this.byId("SiteIdStringPeriodicReview").setText(headerStr);

			var localFinalJson = this.localNewJsonModelForPeriodicReviewChart.getData();

			//	var list = this.byId("tableInprocess");
			//	var oBinding = list.getBinding("items");

			var arrayDeptFilters = [];
			if (this.byId("deptPeriodicReview").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("deptPeriodicReview").getSelectedKeys().length; i++) {

					for (var j = 0; j < localFinalJson.results.length; j++) {
						if (this.byId("deptPeriodicReview").getSelectedKeys()[i] === localFinalJson.results[j].Department) {
							arrayDeptFilters.push(localFinalJson.results[j]);
						}
					}
				}
			} else {
				arrayDeptFilters = localFinalJson.results;
			}
			var results = {
				"results": arrayDeptFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayDocTypeFilters = [];
			if (this.byId("docTypePeriodicReview").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("docTypePeriodicReview").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("docTypePeriodicReview").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].TypeId) {
							arrayDocTypeFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayDocTypeFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayDocTypeFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayCustFilters = [];
			if (this.byId("customerPeriodicReview").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("customerPeriodicReview").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("customerPeriodicReview").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].Customer) {
							arrayCustFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayCustFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayCustFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayStatusFilters = [];
			if (this.byId("authorPeriodicReview").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("authorPeriodicReview").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("authorPeriodicReview").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].AuthorId) {
							arrayStatusFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayStatusFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayStatusFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayStatusFilters1 = [];
			if (this.byId("ownerPeriodicReview").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("ownerPeriodicReview").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("ownerPeriodicReview").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].OwnerId) {
							arrayStatusFilters1.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayStatusFilters1 = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayStatusFilters1
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayPendingUsersFilters = [];
			if (this.byId("userPeriodicReview").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("userPeriodicReview").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("userPeriodicReview").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].PendingUser) {
							arrayPendingUsersFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayPendingUsersFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayPendingUsersFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayFinal = localJsonModelForInProcessChart.getData().results;
			var arrayJdocStatus = [];
			var arrayJdocNumbers = [];
			for (var i = 0; i < arrayFinal.length; i++) {
				arrayJdocStatus.push(arrayFinal[i].PrStatus);
				arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
			}

			arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
				return a.indexOf(x) === j;
			});
			/*if (this.byId("userPeriodicReview").getSelectedKeys().length === 0) {
				arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
					return a.indexOf(x) === j;
				});
			}*/
			//	console.log(arrayJdocStatus);

			var arrayOfJdocNumbers = [];
			for (var k = 0; k < arrayJdocNumbers.length; k++) {
				//	var counterForJdocStatus = 0;

				arrayOfJdocNumbers.push(arrayFinal[k]);

			}

			//	console.log(arrayOfJdocNumbers);

			var arrayOfStatus = [];
			for (var k = 0; k < arrayJdocStatus.length; k++) {
				var counterForJdocStatus = 0;
				for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
					if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].PrStatus) {

						counterForJdocStatus++;

					}

				}
				var data = {
					"Status": arrayJdocStatus[k],
					"Value": counterForJdocStatus
				};
				arrayOfStatus.push(data);
			}
			//	console.log(arrayOfStatus);
			//that.localJsonModelForInProcessStatusDropdown.setData(arrayOfStatus);

			var oVizFrame2 = this.getView().byId("idpiechart4");
			oVizFrame2.setModel(new sap.ui.model.json.JSONModel(null));
			var oModel2 = new sap.ui.model.json.JSONModel();

			var data2 = {
				'DocTypes': arrayOfStatus
			};
			oModel2.setData(data2);

			//      3. Create Viz dataset to feed to the data to the graph
			var oDataset2 = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'Status',
					value: "{Status}"
				}],

				measures: [{
					name: 'Value',
					value: '{Value}'
				}],

				data: {
					path: "/DocTypes"
				}
			});
			//oVizFrame2.setDataset(oDataset2);
			oVizFrame2.getModel().setData(data2);
			this._filtersForPeriodicReview.close();
			this._filtersForPeriodicReview.destroy();
			this._filtersForPeriodicReview = undefined;

			//      4.Set Viz properties
			oVizFrame2.setVizProperties({
				title: {
					text: "Periodic Review Tasks - " + arrayOfJdocNumbers.length
				},
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					drawingEffect: "glossy",
					radius: "0.25"

				},
				dataLabel: {
					visible: true,
					type: "percentage"

				}

			});
			/*	var feedSize2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "size",
					'type': "Measure",
					'values': ["Value"]
				}),
				feedColor2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "color",
					'type': "Dimension",
					'values': ["Status"]
				});
			oVizFrame2.addFeed(feedSize2);
			oVizFrame2.addFeed(feedColor2);
*/

		},
		applyFiltersDocStatusCharts: function(evt) {
			var that = this;
			this.arraySiteDocumentStatus = this.byId("siteDocumentStatus").getSelectedKeys();
			this.arrayAuthorOwnerDrop = this.byId("authorDrop").getSelectedKeys();
			this.arrayAuthorOwnerDrop1 = this.byId("ownerDrop").getSelectedKeys();

			this.arrayDocTypeDropDocumentStatus = this.byId("docTypeDropDocumentStatus").getSelectedKeys();
			this.arrayCustomerDropDocumentStatus = this.byId("CustomerDropDocumentStatus").getSelectedKeys();

			var localFinalJson = this.localNewJsonModelForDocStatusChart.getData();

			var headerStr = "";
			for (var z = 0; z < this.byId("siteDocumentStatus").getSelectedKeys().length; z++) {
				if (z < (this.byId("siteDocumentStatus").getSelectedKeys().length - 1)) {
					headerStr += this.byId("siteDocumentStatus").getSelectedKeys()[z] + ",";
				} else {
					headerStr += this.byId("siteDocumentStatus").getSelectedKeys()[z];
				}
			}
			this.byId("SiteIdStringDocStatus").setText(headerStr);

			//	var list = this.byId("tableInprocess");
			//	var oBinding = list.getBinding("items");

			var arrayDeptFilters = [];
			if (this.byId("authorDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("authorDrop").getSelectedKeys().length; i++) {

					for (var j = 0; j < localFinalJson.results.length; j++) {
						if (this.byId("authorDrop").getSelectedKeys()[i] === localFinalJson.results[j].AuthorId) {
							arrayDeptFilters.push(localFinalJson.results[j]);
						}
					}
				}
			} else {
				arrayDeptFilters = localFinalJson.results;
			}
			var results = {
				"results": arrayDeptFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayDeptFilters1 = [];
			if (this.byId("ownerDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("ownerDrop").getSelectedKeys().length; i++) {

					for (var j = 0; j < localFinalJson.results.length; j++) {
						if (this.byId("ownerDrop").getSelectedKeys()[i] === localFinalJson.results[j].OwnerId) {
							arrayDeptFilters1.push(localFinalJson.results[j]);
						}
					}
				}
			} else {
				arrayDeptFilters1 = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayDeptFilters1
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayDocTypeFilters = [];
			if (this.byId("docTypeDropDocumentStatus").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("docTypeDropDocumentStatus").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("docTypeDropDocumentStatus").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].TypeId) {
							arrayDocTypeFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayDocTypeFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayDocTypeFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayCustFilters = [];
			if (this.byId("CustomerDropDocumentStatus").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("CustomerDropDocumentStatus").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("CustomerDropDocumentStatus").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].Customer) {
							arrayCustFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayCustFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayCustFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayFinal = localJsonModelForInProcessChart.getData().results;
			var arrayJdocStatus = [];
			var arrayJdocNumbers = [];
			for (var i = 0; i < arrayFinal.length; i++) {
				arrayJdocStatus.push(arrayFinal[i].JdocStatus);
				arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
			}

			arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
				return a.indexOf(x) === j;
			});

			/*arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
				return a.indexOf(x) === j;
			});*/

			//	console.log(arrayJdocStatus);

			var arrayOfJdocNumbers = [];
			for (var k = 0; k < arrayJdocNumbers.length; k++) {
				//	var counterForJdocStatus = 0;

				arrayOfJdocNumbers.push(arrayFinal[k]);

			}

			//	console.log(arrayOfJdocNumbers);

			var arrayOfStatus = [];
			for (var k = 0; k < arrayJdocStatus.length; k++) {
				var counterForJdocStatus = 0;
				for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
					if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].JdocStatus) {

						counterForJdocStatus++;

					}

				}
				var data = {
					"Status": arrayJdocStatus[k],
					"Value": counterForJdocStatus
				};
				arrayOfStatus.push(data);
			}
			//	console.log(arrayOfStatus);
			that.localJsonModelForInProcessStatusDropdown.setData(arrayOfStatus);

			var oVizFrame3 = this.getView().byId("idpiechart3");
			oVizFrame3.setModel(new sap.ui.model.json.JSONModel(null));
			var oModel3 = new sap.ui.model.json.JSONModel();

			var data3 = {
				'DocStatus': arrayOfStatus
			};
			oModel3.setData(data3);

			//      3. Create Viz dataset to feed to the data to the graph
			var oDataset3 = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'Status',
					value: "{Status}"
				}],

				measures: [{
					name: 'Value',
					value: '{Value}'
				}],

				data: {
					path: "/DocStatus"
				}
			});
			//oVizFrame2.setDataset(oDataset2);
			oVizFrame3.getModel().setData(data3);
			this._filtersForDocStatusChart.close();
			this._filtersForDocStatusChart.destroy();
			this._filtersForDocStatusChart = undefined;

			//      4.Set Viz properties
			oVizFrame3.setVizProperties({
				title: {
					text: "Documents Status - " + arrayOfJdocNumbers.length
				},
				plotArea: {
					colorPalette: d3.scale.category10().range(),
					drawingEffect: "glossy",
					radius: "0.25"

				},
				dataLabel: {
					visible: true,
					type: "percentage"

				}

			});
			/*	var feedSize2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "size",
					'type': "Measure",
					'values': ["Value"]
				}),
				feedColor2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "color",
					'type': "Dimension",
					'values': ["Status"]
				});
			oVizFrame2.addFeed(feedSize2);
			oVizFrame2.addFeed(feedColor2);
*/

		},
		applyFiltersDocumentTypesCharts: function(evt) {
			var that = this;
			var localFinalJson = this.localNewJsonModelForDocumentTypesChart.getData();

			//	var list = this.byId("tableInprocess");
			//	var oBinding = list.getBinding("items");

			this.arrayCustomerDocumentTypes = this.byId("customerDocumentTypes").getSelectedKeys();
			this.arrayStatusDocumentTypes = this.byId("statusDocumentTypes").getSelectedKeys();
			this.arrayAuthorOwnerDocumentTypes = this.byId("authorDocumentTypes").getSelectedKeys();
			this.arrayAuthorOwnerDocumentTypes1 = this.byId("ownerDocumentTypes").getSelectedKeys();
			this.arraydocumentTypes = this.byId("docTypeDrop").getSelectedKeys();

			this.arraySiteDocumentTypes = this.byId("siteDocumentTypes").getSelectedKeys();

			var headerStr = "";
			for (var z = 0; z < this.byId("siteDocumentTypes").getSelectedKeys().length; z++) {
				if (z < (this.byId("siteDocumentTypes").getSelectedKeys().length - 1)) {
					headerStr += this.byId("siteDocumentTypes").getSelectedKeys()[z] + ",";
				} else {
					headerStr += this.byId("siteDocumentTypes").getSelectedKeys()[z];
				}
			}
			this.byId("SiteIdStringDocType").setText(headerStr);

			var arrayDeptFilters = [];
			if (this.byId("customerDocumentTypes").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("customerDocumentTypes").getSelectedKeys().length; i++) {

					for (var j = 0; j < localFinalJson.results.length; j++) {
						if (this.byId("customerDocumentTypes").getSelectedKeys()[i] === localFinalJson.results[j].Customer) {
							arrayDeptFilters.push(localFinalJson.results[j]);
						}
					}
				}
			} else {
				arrayDeptFilters = localFinalJson.results;
			}
			var results = {
				"results": arrayDeptFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayDocTypeFilters = [];
			if (this.byId("statusDocumentTypes").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("statusDocumentTypes").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("statusDocumentTypes").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].JdocStatus) {
							arrayDocTypeFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayDocTypeFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayDocTypeFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayCustFilters = [];
			if (this.byId("authorDocumentTypes").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("authorDocumentTypes").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("authorDocumentTypes").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].AuthorId) {
							arrayCustFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayCustFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayCustFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);
			
			var arrayDeptFilters = [];
			if (this.byId("docTypeDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("docTypeDrop").getSelectedKeys().length; i++) {
					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("docTypeDrop").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].TypeId) {
							arrayDeptFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayDeptFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayDeptFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayCustFilters1 = [];
			if (this.byId("ownerDocumentTypes").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("ownerDocumentTypes").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("ownerDocumentTypes").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].OwnerId) {
							arrayCustFilters1.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayCustFilters1 = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayCustFilters1
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayFinal = localJsonModelForInProcessChart.getData().results;
			var arrayJdocStatus = [] , arrayJdocNumbersDocTypes1 = [], arrayJdocNumbersDocTypes1Temp = [] ;
			var arrayJdocNumbers = [];
			for (var i = 0; i < arrayFinal.length; i++) {
				var typeArray = {"TypeId":arrayFinal[i].TypeId, "TypeDesc":arrayFinal[i].TypeDesc,"SubType":arrayFinal[i].SubType };
				arrayJdocNumbersDocTypes1Temp.push(typeArray);
				arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
			}

			// arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
			// 	return a.indexOf(x) === j;
			// });
			arrayJdocStatus = arrayJdocNumbersDocTypes1Temp.filter((elem, index, self) => self.findIndex((t) => {return (t.TypeId === elem.TypeId && t.SubType === elem.SubType)}) === index);
			/*	arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
					return a.indexOf(x) === j;
				});*/

			//	console.log(arrayJdocStatus);

			var arrayOfJdocNumbers = [];
			for (var k = 0; k < arrayJdocNumbers.length; k++) {
				//	var counterForJdocStatus = 0;

				arrayOfJdocNumbers.push(arrayFinal[k]);

			}

			//	console.log(arrayOfJdocNumbers);

			var arrayOfStatus = [];
			for (var k = 0; k < arrayJdocStatus.length; k++) {
				var counterForJdocStatus = 0;
				for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
					if (arrayJdocStatus[k].TypeId === arrayOfJdocNumbers[j].TypeId && arrayJdocStatus[k].SubType === arrayOfJdocNumbers[j].SubType) {

						counterForJdocStatus++;

					}

				}
				var data = {
					"Status":arrayJdocStatus[k].TypeId+"~"+ arrayJdocStatus[k].SubType +"~"+ arrayJdocStatus[k].TypeDesc,
					"Value": counterForJdocStatus
				};
				arrayOfStatus.push(data);
			}
			//	console.log(arrayOfStatus);
			that.localJsonModelForInProcessStatusDropdown.setData(arrayOfStatus);

			var oVizFrame33 = this.getView().byId("idpiechart33");
			oVizFrame33.setModel(new sap.ui.model.json.JSONModel(null));
			var oModel33 = new sap.ui.model.json.JSONModel();

			var data33 = {
				'DocTypes': arrayOfStatus
			};
			oModel33.setData(data33);

			//      3. Create Viz dataset to feed to the data to the graph
			var oDataset33 = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'Status',
					value: "{Status}"
				}],

				measures: [{
					name: 'Value',
					value: '{Value}'
				}],

				data: {
					path: "/DocTypes"
				}
			});
			//oVizFrame2.setDataset(oDataset2);
			oVizFrame33.getModel().setData(data33);
			this._filtersForDocumentTypes.close();
			this._filtersForDocumentTypes.destroy();
			this._filtersForDocumentTypes = undefined;

			//      4.Set Viz properties
			oVizFrame33.setVizProperties({
				title: {
					text: "Document Types - " + arrayJdocStatus.length
				},
				plotArea: {
					colorPalette: d3.scale.category10().range(),
					drawingEffect: "glossy",
					radius: "0.25"

				},
				dataLabel: {
					visible: true,
					type: "percentage"

				}

			});
			/*	var feedSize2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "size",
					'type': "Measure",
					'values': ["Value"]
				}),
				feedColor2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
					'uid': "color",
					'type': "Dimension",
					'values': ["Status"]
				});
			oVizFrame2.addFeed(feedSize2);
			oVizFrame2.addFeed(feedColor2);
*/

		},
		applyFiltersInProcessCharts: function(evt) {
			var that = this;
			this.arraySiteInProcess = this.byId("siteInProcess").getSelectedKeys();
			this.arrayDeptInProcess = this.byId("deptDrop").getSelectedKeys();
			this.arrayDocTypeInProcess = this.byId("docTypeDrop").getSelectedKeys();
			this.arrayCustomerInProcess = this.byId("CustomerDrop").getSelectedKeys();
			this.arrayStatusInProcess = this.byId("statusDrop").getSelectedKeys();
			this.arrayUserInProcess = this.byId("UserDrop").getSelectedKeys();

			var localFinalJson = this.localNewJsonModelForInProcessChart.getData();

			/*var arrayFinal = this.localNewJsonModelForInProcessChart.getData().results;
			for (var a = 0; a < arrayFinal.length; a++) {
				var jdocNo = arrayFinal[a].JdocNumber;
				var jdocRev = arrayFinal[a].JdocRevision;
				var pendingUser = arrayFinal[a].PendingUser;
				var wfName = arrayFinal[a].Workflow;
				var stepName = arrayFinal[a].Step;
				for (var b = arrayFinal.length - 1; b > a; b--) {
					if (arrayFinal[b].JdocNumber === jdocNo && arrayFinal[b].JdocRevision === jdocRev && arrayFinal[b].PendingUser ===
						pendingUser && arrayFinal[b].Workflow === wfName && arrayFinal[b].Step === stepName) {
						arrayFinal.splice(b, 1);
					}
				}
			}*/
			//	var localFinalJson = arrayFinal;

			//	var list = this.byId("tableInprocess");
			//	var oBinding = list.getBinding("items");

			var arrayDeptFilters = [];
			var headerStr = "";
			for (var z = 0; z < this.byId("siteInProcess").getSelectedKeys().length; z++) {
				if (z < (this.byId("siteInProcess").getSelectedKeys().length - 1)) {
					headerStr += this.byId("siteInProcess").getSelectedKeys()[z] + ",";
				} else {
					headerStr += this.byId("siteInProcess").getSelectedKeys()[z];
				}
			}
			this.byId("SiteIdString").setText(headerStr);

			this.inProcessChartSelectedDept = this.byId("deptDrop").getSelectedKeys();

			if (this.byId("deptDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("deptDrop").getSelectedKeys().length; i++) {
					for (var j = 0; j < localFinalJson.results.length; j++) {
						if (this.byId("deptDrop").getSelectedKeys()[i] === localFinalJson.results[j].Department) {
							arrayDeptFilters.push(localFinalJson.results[j]);
						}
					}
				}
			} else {
				arrayDeptFilters = localFinalJson.results;
			}
			var results = {
				"results": arrayDeptFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayDocTypeFilters = [];
			if (this.byId("docTypeDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("docTypeDrop").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("docTypeDrop").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].TypeId) {
							arrayDocTypeFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayDocTypeFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayDocTypeFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayCustFilters = [];
			if (this.byId("CustomerDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("CustomerDrop").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("CustomerDrop").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].Customer) {
							arrayCustFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayCustFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayCustFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayStatusFilters = [];
			if (this.byId("statusDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("statusDrop").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("statusDrop").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].ProcessType) {
							arrayStatusFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayStatusFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayStatusFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayPendingUsersFilters = [];
			if (this.byId("UserDrop").getSelectedKeys().length > 0) {
				for (var i = 0; i < this.byId("UserDrop").getSelectedKeys().length; i++) {

					for (var j = 0; j < localJsonModelForInProcessChart.getData().results.length; j++) {
						if (this.byId("UserDrop").getSelectedKeys()[i] === localJsonModelForInProcessChart.getData().results[j].PendingUser) {
							arrayPendingUsersFilters.push(localJsonModelForInProcessChart.getData().results[j]);
						}
					}
				}
			} else {
				arrayPendingUsersFilters = localJsonModelForInProcessChart.getData().results;
			}
			var results = {
				"results": arrayPendingUsersFilters
			};
			var localJsonModelForInProcessChart = new sap.ui.model.json.JSONModel();
			localJsonModelForInProcessChart.setData(results);

			var arrayFinal = localJsonModelForInProcessChart.getData().results;

			var arrayJdocStatus = [];
			var arrayJdocNumbers = [];
			for (var i = 0; i < arrayFinal.length; i++) {
				arrayJdocStatus.push(arrayFinal[i].ProcessType);
				arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
			}

			arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
				return a.indexOf(x) === j;
			});
			/*if (this.byId("UserDrop").getSelectedKeys().length === 0) {
				arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
					return a.indexOf(x) === j;
				});
			}*/
			//	console.log(arrayJdocStatus);

			var arrayOfJdocNumbers = [];
			for (var k = 0; k < arrayJdocNumbers.length; k++) {
				//	var counterForJdocStatus = 0;

				arrayOfJdocNumbers.push(arrayFinal[k]);
			}

			//	console.log(arrayOfJdocNumbers);

			var arrayOfStatus = [];
			for (var k = 0; k < arrayJdocStatus.length; k++) {
				var counterForJdocStatus = 0;
				for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
					if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].ProcessType) {

						counterForJdocStatus++;

					}

				}
				var data = {
					"TaskType": arrayJdocStatus[k],
					"Value": counterForJdocStatus
				};
				arrayOfStatus.push(data);
			}
			//	console.log(arrayOfStatus);
			that.localJsonModelForInProcessStatusDropdown.setData(arrayOfStatus);

			var oVizFrame2 = this.getView().byId("idpiechart2");
			oVizFrame2.setModel(new sap.ui.model.json.JSONModel(null));
			var oModel2 = new sap.ui.model.json.JSONModel();

			var data2 = {
				'DocStatus': arrayOfStatus
			};
			oModel2.setData(data2);

			//      3. Create Viz dataset to feed to the data to the graph
			var oDataset2 = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: 'TaskType',
					value: "{TaskType}"
				}],

				measures: [{
					name: 'Value',
					value: '{Value}'
				}],

				data: {
					path: "/DocStatus"
				}
			});
			//oVizFrame2.setDataset(oDataset2);
			oVizFrame2.getModel().setData(data2);
			oVizFrame2.setModel(oModel2);
			this._filtersForInProcessChart.close();
			this._filtersForInProcessChart.destroy();
			this._filtersForInProcessChart = undefined;

			//      4.Set Viz properties
			oVizFrame2.setVizProperties({
				title: {
					text: "In-process Documents - " + arrayOfJdocNumbers.length
				},
				plotArea: {
					colorPalette: d3.scale.category10().range(),
					drawingEffect: "glossy",
					radius: "0.25"

				}

			});
// 			/*	var feedSize2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
// 					'uid': "size",
// 					'type': "Measure",
// 					'values': ["Value"]
// 				}),
// 				feedColor2 = new sap.viz.ui5.controls.common.feeds.FeedItem({
// 					'uid': "color",
// 					'type': "Dimension",
// 					'values': ["Status"]
// 				});
// 			oVizFrame2.addFeed(feedSize2);
// 	 		oVizFrame2.addFeed(feedColor2);
// */
		},
		cancelDocumentTypesDialog: function(evt) {
			this._oSectorSelectDocType.close();
			this._oSectorSelectDocType.destroy();
			this._oSectorSelectDocType = undefined;
		},
		cancelDocStatusDialog: function(evt) {
			this._oSectorSelectDocStatus.close();
			this._oSectorSelectDocStatus.destroy();
			this._oSectorSelectDocStatus = undefined;

		},
		cancelPeriodicReviewDialog: function(evt) {

			this._oSectorSelectPeriodicReview.close();
			this._oSectorSelectPeriodicReview.destroy();
			this._oSectorSelectPeriodicReview = undefined;

		},
		cancelInProcessDialog: function(evt) {
			this._oTableInProcessChart.close();
			this._oTableInProcessChart.destroy();
			this._oTableInProcessChart = undefined;
		},
		cancelFiltersDocumentTypes: function(evt) {
			this._filtersForDocumentTypes.close();
			this._filtersForDocumentTypes.destroy();
			this._filtersForDocumentTypes = undefined;
		},
		cancelFiltersPeriodicReview: function(evt) {
			this._filtersForPeriodicReview.close();
			this._filtersForPeriodicReview.destroy();
			this._filtersForPeriodicReview = undefined;
		},
		cancelFiltersDocStatus: function(evt) {
			this._filtersForDocStatusChart.close();
			this._filtersForDocStatusChart.destroy();
			this._filtersForDocStatusChart = undefined;
		},
		cancelFiltersInProcess: function(evt) {
			this._filtersForInProcessChart.close();
			this._filtersForInProcessChart.destroy();
			this._filtersForInProcessChart = undefined;
		},
		changeSiteDocumentTypes: function(evt) {

			//	alert('hello');
			var that = this;
			var arrayFilters = [];
			for (var i = 0; i < this.byId("siteDocumentTypes").getSelectedKeys().length; i++) {
				var oFilter = new sap.ui.model.Filter("SiteId", "EQ", this.byId("siteDocumentTypes").getSelectedKeys()[i]);
				arrayFilters.push(
					oFilter);
			}
			if (evt.mParameters.value !== undefined && evt.mParameters.value.split("-") !== undefined && evt.mParameters.value.split("-").length >
				0 && evt.mParameters.value.split("-")[0] !== "") {
				var oFilter2 = new sap.ui.model.Filter("SiteId", "EQ", evt.mParameters.value.split("-")[0]);

				arrayFilters.push(oFilter2);
			}

			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			sap.ui.core.BusyIndicator.show(0);
			oModelVariantO1.read("JdocChartsSet", {
				filters: arrayFilters,
				urlParameters: {
					"$expand": [
						"NavToDocTypeChart,NavToSite,NavToDocStatusChart,NavToDocType,NavToOwner,NavToDocPrChart,NavToDepartment,NavToAuthor,NavToDocInChart,NavToCustomer,NavToPendingUser"
					]
				},
				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();

					//	that.localNewJsonModelForDocumentTypesChart.setData(oData.results[0].NavToDocTypeChart);

					//that.byId("statusDocumentTypes").getModel().setData(that.localJsonModelForDocumentTypesStatusDropdown.getData());
					that.byId("authorDocumentTypes").getModel().setData(oData.results[0].NavToAuthor);
					that.byId("ownerDocumentTypes").getModel().setData(oData.results[0].NavToOwner);

					that.byId("docTypeDrop").getModel().setData(oData.results[0].NavToDocType);
					that.byId("customerDocumentTypes").getModel().setData(oData.results[0].NavToCustomer);

					var arrayFinal = oData.results[0].NavToDocTypeChart.results;
					var arrayJdocStatus = [];
					var arrayJdocNumbers = [];

					for (var a = 0; a < arrayFinal.length; a++) {
						var jdocNo = arrayFinal[a].JdocNumber;
						var jdocRev = arrayFinal[a].JdocRevision;
						for (var b = arrayFinal.length - 1; b > a; b--) {
							if (arrayFinal[b].JdocNumber === jdocNo && arrayFinal[b].JdocRevision ===
								jdocRev) {
								arrayFinal.splice(b, 1);
							}
						}
					}

					var results = {
						"results": arrayFinal
					};
					that.localNewJsonModelForDocumentTypesChart.setData(results);

					for (var i = 0; i < arrayFinal.length; i++) {
						arrayJdocStatus.push(arrayFinal[i].JdocStatus);
						arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
					}

					arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					//	console.log(arrayJdocStatus);

					var arrayOfJdocNumbers = [];
					for (var k = 0; k < arrayJdocNumbers.length; k++) {
						//	var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinal.length; j++) {
							if (arrayJdocNumbers[k] === arrayFinal[j].JdocNumber) {

								arrayOfJdocNumbers.push(arrayFinal[j]);
								break;
							}

						}

					}

					//	console.log(arrayOfJdocNumbers);

					var arrayOfStatus = [];
					for (var k = 0; k < arrayJdocStatus.length; k++) {
						var counterForJdocStatus = 0;
						for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
							if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].JdocStatus) {

								counterForJdocStatus++;

							}

						}
						var data = {
							"Status": arrayJdocStatus[k],
							"Value": counterForJdocStatus
						};
						arrayOfStatus.push(data);
					}
					//	console.log(arrayOfStatus);
					that.byId("statusDocumentTypes").getModel().setData(arrayOfStatus);

				},
				error: function(err) {
					//		alert("Service Failed");
				}
			});

		},
		changeSiteDocumentStatus: function(evt) {

			//	alert('hello');
			var that = this;
			var arrayFilters = [];
			for (var i = 0; i < this.byId("siteDocumentStatus").getSelectedKeys().length; i++) {
				var oFilter = new sap.ui.model.Filter("SiteId", "EQ", this.byId("siteDocumentStatus").getSelectedKeys()[i]);
				arrayFilters.push(
					oFilter);
			}
			if (evt.mParameters.value !== undefined && evt.mParameters.value.split("-") !== undefined && evt.mParameters.value.split("-").length >
				0 && evt.mParameters.value.split("-")[0] !== "") {
				var oFilter2 = new sap.ui.model.Filter("SiteId", "EQ", evt.mParameters.value.split("-")[0]);

				arrayFilters.push(oFilter2);
			}

			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			sap.ui.core.BusyIndicator.show(0);
			oModelVariantO1.read("JdocChartsSet", {
				filters: arrayFilters,
				urlParameters: {
					"$expand": [
						"NavToDocTypeChart,NavToSite,NavToDocStatusChart,NavToDocType,NavToOwner,NavToDocPrChart,NavToDepartment,NavToAuthor,NavToDocInChart,NavToCustomer,NavToPendingUser"
					]
				},
				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();

					that.byId("docTypeDropDocumentStatus").getModel().setData(oData.results[0].NavToDocType);
					that.byId("authorDrop").getModel().setData(oData.results[0].NavToAuthor);
					that.byId("ownerDrop").getModel().setData(oData.results[0].NavToOwner);

					//	that.byId("UserDrop").getModel().setData(oData.results[0].NavToPendingUser);
					that.byId("CustomerDropDocumentStatus").getModel().setData(oData.results[0].NavToCustomer);

					var arrayFinal = oData.results[0].NavToDocStatusChart.results;
					var arrayJdocStatus = [];
					var arrayJdocNumbers = [];

					for (var a = 0; a < arrayFinal.length; a++) {
						var status = arrayFinal[a].JdocStatus;
						var jdocNo = arrayFinal[a].JdocNumber;
						var jdocRev = arrayFinal[a].JdocRevision;
						for (var b = arrayFinal.length - 1; b > a; b--) {
							if (arrayFinal[b].JdocStatus === status && arrayFinal[b].JdocNumber === jdocNo && arrayFinal[b].JdocRevision ===
								jdocRev) {
								arrayFinal.splice(b, 1);
								//	break;
							}
							/*else {
								docStatusFinalDocsArray.push(arrayFinalDocStatus[a]);
							}*/
						}
						//	docStatusFinalDocsArray.push(arrayFinalDocStatus[a]);

					}
					var results = {
						"results": arrayFinal
					};
					that.localNewJsonModelForDocStatusChart.setData(results);
					for (i = 0; i < arrayFinal.length; i++) {
						arrayJdocStatus.push(arrayFinal[i].JdocStatus);
						arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
					}

					arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					//	console.log(arrayJdocStatus);

					var arrayOfJdocNumbers = [];
					for (var k = 0; k < arrayJdocNumbers.length; k++) {
						//	var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinal.length; j++) {
							if (arrayJdocNumbers[k] === arrayFinal[j].JdocNumber) {

								arrayOfJdocNumbers.push(arrayFinal[j]);
								break;
							}

						}

					}

					//	console.log(arrayOfJdocNumbers);

					var arrayOfStatus = [];
					for (k = 0; k < arrayJdocStatus.length; k++) {
						var counterForJdocStatus = 0;
						for (j = 0; j < arrayOfJdocNumbers.length; j++) {
							if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].JdocStatus) {

								counterForJdocStatus++;

							}

						}
						var data = {
							"Status": arrayJdocStatus[k],
							"Value": counterForJdocStatus
						};
						arrayOfStatus.push(data);
					}
					//	console.log(arrayOfStatus);
					//	that.byId("statusDrop").getModel().setData(arrayOfStatus);

				},
				error: function(err) {
					//		alert("Service Failed");
				}
			});

		},
		changeSitePeriodicReview: function(evt) {

			//	alert('hello');
			var that = this;
			var arrayFilters = [];
			for (var i = 0; i < this.byId("sitePeriodicReview").getSelectedKeys().length; i++) {
				var oFilter = new sap.ui.model.Filter("SiteId", "EQ", this.byId("sitePeriodicReview").getSelectedKeys()[i]);
				arrayFilters.push(
					oFilter);
			}
			if (evt.mParameters.value !== undefined && evt.mParameters.value.split("-") !== undefined && evt.mParameters.value.split("-").length >
				0 && evt.mParameters.value.split("-")[0] !== "") {
				var oFilter2 = new sap.ui.model.Filter("SiteId", "EQ", evt.mParameters.value.split("-")[0]);

				arrayFilters.push(oFilter2);
			}

			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			sap.ui.core.BusyIndicator.show(0);
			oModelVariantO1.read("JdocChartsSet", {
				filters: arrayFilters,
				urlParameters: {
					"$expand": [
						"NavToDocTypeChart,NavToSite,NavToDocStatusChart,NavToDocType,NavToOwner,NavToDocPrChart,NavToDepartment,NavToAuthor,NavToDocInChart,NavToCustomer,NavToPendingUser"
					]
				},
				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();
					//console.log(oData);
					//	that.localNewJsonModelForPeriodicReviewChart.setData(oData.results[0].NavToDocPrChart);

					//	this.byId('statusDrop').setModel(this.localJsonModelForInProcessStatusDropdown);
					//	that.byId("statusDrop").getModel().setData(oData.results[0].NavToDocType);
					that.byId("docTypePeriodicReview").getModel().setData(oData.results[0].NavToDocType);
					that.byId("deptPeriodicReview").getModel().setData(oData.results[0].NavToDepartment);
					that.byId("userPeriodicReview").getModel().setData(oData.results[0].NavToPendingUser);
					that.byId("customerPeriodicReview").getModel().setData(oData.results[0].NavToCustomer);
					that.byId("authorPeriodicReview").getModel().setData(oData.results[0].NavToAuthor);
					that.byId("ownerPeriodicReview").getModel().setData(oData.results[0].NavToOwner);

					var arrayFinal = oData.results[0].NavToDocPrChart.results;
					var arrayJdocStatus = [];
					var arrayJdocNumbers = [];

					for (var a = 0; a < arrayFinal.length; a++) {
						var jdocNo = arrayFinal[a].JdocNumber;
						var jdocRev = arrayFinal[a].JdocRevision;
						for (var b = arrayFinal.length - 1; b > a; b--) {
							if (arrayFinal[b].JdocNumber === jdocNo && arrayFinal[b].JdocRevision ===
								jdocRev) {
								arrayFinal.splice(b, 1);
							}
						}
					}
					var results = {
						"results": arrayFinal
					};
					that.localNewJsonModelForPeriodicReviewChart.setData(results);
					for (i = 0; i < arrayFinal.length; i++) {
						arrayJdocStatus.push(arrayFinal[i].PrStatus);
						arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
					}

					arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					//	console.log(arrayJdocStatus);

					var arrayOfJdocNumbers = [];
					for (var k = 0; k < arrayJdocNumbers.length; k++) {
						//	var counterForJdocStatus = 0;
						for (var j = 0; j < arrayFinal.length; j++) {
							if (arrayJdocNumbers[k] === arrayFinal[j].JdocNumber) {

								arrayOfJdocNumbers.push(arrayFinal[j]);
								break;
							}

						}

					}

					//	console.log(arrayOfJdocNumbers);

					var arrayOfStatus = [];
					for (var k = 0; k < arrayJdocStatus.length; k++) {
						var counterForJdocStatus = 0;
						for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
							if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].PrStatus) {

								counterForJdocStatus++;

							}

						}
						var data = {
							"Status": arrayJdocStatus[k],
							"Value": counterForJdocStatus
						};
						arrayOfStatus.push(data);
					}
					//	console.log(arrayOfStatus);
					//	that.byId("statusDrop").getModel().setData(arrayOfStatus);

				},
				error: function(err) {
					//		alert("Service Failed");
				}
			});

		},
		changeSiteInProcess: function(evt) {
			//	alert('hello');
			var that = this;
			var arrayFilters = [];

			//code for creating site text in chart header

			for (var i = 0; i < this.byId("siteInProcess").getSelectedKeys().length; i++) {
				var oFilter = new sap.ui.model.Filter("SiteId", "EQ", this.byId("siteInProcess").getSelectedKeys()[i]);
				arrayFilters.push(
					oFilter);
			}
			if (evt.mParameters.value !== undefined && evt.mParameters.value.split("-") !== undefined && evt.mParameters.value.split("-").length >
				0 && evt.mParameters.value.split("-")[0] !== "") {
				var oFilter2 = new sap.ui.model.Filter("SiteId", "EQ", evt.mParameters.value.split("-")[0]);

				arrayFilters.push(oFilter2);
			}

			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			sap.ui.core.BusyIndicator.show(0);
			oModelVariantO1.read("JdocChartsSet", {
				filters: arrayFilters,
				urlParameters: {
					"$expand": [
						"NavToDocTypeChart,NavToSite,NavToDocStatusChart,NavToDocType,NavToOwner,NavToDocPrChart,NavToDepartment,NavToAuthor,NavToDocInChart,NavToCustomer,NavToPendingUser"
					]
				},
				success: function(oData, response) {
					sap.ui.core.BusyIndicator.hide();
					//console.log(oData);
					that.localNewJsonModelForInProcessChart.setData(oData.results[0].NavToDocInChart);

					//	this.byId('statusDrop').setModel(this.localJsonModelForInProcessStatusDropdown);
					//	that.byId("statusDrop").getModel().setData(oData.results[0].NavToDocType);
					that.byId("docTypeDrop").getModel().setData(oData.results[0].NavToDocType);

					//	this.deptInProcessTable = oData.results[0].NavToDocType;

					that.byId("deptDrop").getModel().setData(oData.results[0].NavToDepartment);
					that.byId("UserDrop").getModel().setData(oData.results[0].NavToPendingUser);
					that.byId("CustomerDrop").getModel().setData(oData.results[0].NavToCustomer);

					var arrayFinal = oData.results[0].NavToDocInChart.results;

					for (var a = 0; a < arrayFinal.length; a++) {
						var jdocNo = arrayFinal[a].JdocNumber;
						var jdocRev = arrayFinal[a].JdocRevision;
						var pendingUser = arrayFinal[a].PendingUser;
						var wfName = arrayFinal[a].Workflow;
						var stepName = arrayFinal[a].Step;
						for (var b = arrayFinal.length - 1; b > a; b--) {
							if (arrayFinal[b].JdocNumber === jdocNo && arrayFinal[b].JdocRevision === jdocRev && arrayFinal[b].PendingUser ===
								pendingUser && arrayFinal[b].Workflow === wfName && arrayFinal[b].Step === stepName) {
								arrayFinal.splice(b, 1);
							}
						}
					}

					var arrayJdocStatus = [];
					var arrayJdocNumbers = [];
					for (i = 0; i < arrayFinal.length; i++) {
						arrayJdocStatus.push(arrayFinal[i].ProcessType);
						arrayJdocNumbers.push(arrayFinal[i].JdocNumber);
					}

					arrayJdocStatus = arrayJdocStatus.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});
					/*arrayJdocNumbers = arrayJdocNumbers.filter(function(x, j, a) {
						return a.indexOf(x) === j;
					});*/
					//	console.log(arrayJdocStatus);

					var arrayOfJdocNumbers = [];
					for (var k = 0; k < arrayJdocNumbers.length; k++) {
						for (var j = 0; j < arrayFinal.length; j++) {
							if (arrayJdocNumbers[k] === arrayFinal[j].JdocNumber) {

								arrayOfJdocNumbers.push(arrayFinal[j]);
								break;
							}

						}

					}

					//	console.log(arrayOfJdocNumbers);

					var arrayOfStatus = [];
					for (var k = 0; k < arrayJdocStatus.length; k++) {
						var counterForJdocStatus = 0;
						for (var j = 0; j < arrayOfJdocNumbers.length; j++) {
							if (arrayJdocStatus[k] === arrayOfJdocNumbers[j].JdocStatus) {

								counterForJdocStatus++;

							}

						}
						var data = {
							"Status": arrayJdocStatus[k],
							"Value": counterForJdocStatus
						};
						arrayOfStatus.push(data);
					}
					//	console.log(arrayOfStatus);
					that.byId("statusDrop").getModel().setData(arrayOfStatus);

				},
				error: function(err) {
					//		alert("Service Failed");
				}
			});

		},
		onSectorSelect: function(oEvent) {
			var selectedSector = oEvent.getParameter("data")[0].data.Status;

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("TableView", {
				sector: selectedSector
			});

		},
		/*	onBeforeRebindTable: function(evt) {
				var mBindingParams = evt.getParameter("bindingParams");
				mBindingParams.filters.push(new sap.ui.model.Filter("SiteId", "EQ", "15"));
				mBindingParams.parameters["expand"] = "NavToSiteList,NavToSiteJdocsList";
			},
		*/
		onFilter: function() {

			/*	if (!this._oControlledCopiesReportTable) {
					this._oControlledCopiesReportTable = sap.ui.xmlfragment(this.getView().getId(),
						"JABIL_FINAL_JDOC360.fragments.PersonalisationDialogForControlledCopies", this);
					this.getView().addDependent(this._oControlledCopiesReportTable);
				}
				this._oControlledCopiesReportTable.open();*/

			var oSmartTable = this.byId("smartTable1");
			if (oSmartTable) {
				oSmartTable.openPersonalisationDialog("Filter");
			}

		},
		startFilter: function() {
			var oSmartTable = this.byId("smartTable1");
			var column, operator, value;
			var aFilters;
			if (oSmartTable) {

				if (this.byId("columnsDD").getSelectedKey() === "jDocNumber") {
					column = "JdocNumber";
				}
				if (this.byId("operatorDD").getSelectedKey() === "EQ") {
					operator = "EQ";
				}
				value = this.byId("valueColumn").getValue();

				var filteredData = new sap.ui.model.json.JSONModel();
				filteredData.setData(JSON.parse(JSON.stringify(this.dataRecievedControlledCopies)));
				this.getView().byId("controlledCopiesTable").setData(filteredData);
				var filter = new Filter(column, operator, value);
				aFilters.push(filter);
				this.getView().byId("controlledCopiesTable").getBinding("items").filter(aFilters); //, "Application"
			}
		},
		linkedDocumentsReport: function(evt) {
			var that = this;
			if (!this._oLinkedDocumentsReport) {
				this._oLinkedDocumentsReport = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.LinkedDocumentsReport", this);
				this.getView().addDependent(this._oLinkedDocumentsReport);
			}

			this.byId("siteIdDropdownLinkedDocs").setModel(this.jsonModelForSite, "siteModel");
			this.byId("siteIdDropdownLinkedDocs").setSelectedKey(this.localInitialSite);

			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);

			var oFilter1 = new sap.ui.model.Filter("SiteId", "EQ", this.localInitialSite);
			oModelVariantO1.read("SrchHelpLinkedJdocsSet", {
				filters: [oFilter1],
				success: function(data2) {
					var oModel2 = new JSONModel();
					

					//that.getView().setModel(oModel2, "docNumberModel");
					//	that.byId("docNumberDropDown").setSelectedKeys(oModel2.getData().results[0].TypeId);
					
					//MTest-JDoc360-App-Issue#264 & 265 : commented above 2 lines and wrote the below code with for loop to remove duplicates
					var j = [],docNumberModel2final = [];
					for(var i = 0; i < data2.results.length;++i){
    							if(j.indexOf(data2.results[i].JdocNumber) === -1){
    								j.push(data2.results[i].JdocNumber);
    								docNumberModel2final.push(data2.results[i]);
    							}
						
					}
					oModel2.setData(docNumberModel2final);
						that.getView().setModel(oModel2, "docNumberModel");
					
				}
			}, this);

			this._oLinkedDocumentsReport.open();
		},
		cancelLinkedDocumentsReport: function() {
			this._oLinkedDocumentsReport.close();
			this._oLinkedDocumentsReport.destroy();
			this._oLinkedDocumentsReport = undefined;
		},
		extensionRequestReport: function() {
			if (!this._oExtensionRequestReport) {
				this._oExtensionRequestReport = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.ExtensionRequestReport", this);
				this.getView().addDependent(this._oExtensionRequestReport);
			}
			this._oExtensionRequestReport.open();
		},
		cancelExtensionRequestReport: function() {
			this._oExtensionRequestReport.close();
			this._oExtensionRequestReport.destroy();
			this._oExtensionRequestReport = undefined;
		},
		waiverReport: function() {
			if (!this._oWaiverReport) {
				this._oWaiverReport = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.WaiverReport", this);
				this.getView().addDependent(this._oWaiverReport);
			}
			this._oWaiverReport.open();
		},
		cancelwaiverReport: function() {
			this._oWaiverReport.close();
			this._oWaiverReport.destroy();
			this._oWaiverReport = undefined;
		},
		controlledCopiesReport: function() {
			if (!this._oControlledCopiesReport) {
				this._oControlledCopiesReport = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.ControlledCopiesReport", this);
				this.getView().addDependent(this._oControlledCopiesReport);
			}
			this.byId("siteIdDropdownControlledCopies").setModel(this.jsonModelForSite, "siteModel");
			this.byId("siteIdDropdownControlledCopies").setSelectedKey(this.localInitialSite);
			this._oControlledCopiesReport.open();
		},
		cancelControlledCopiesReport: function() {
			this._oControlledCopiesReport.close();
			this._oControlledCopiesReport.destroy();
			this._oControlledCopiesReport = undefined;
		},
		onAcknowledgement: function(evt) {

			var that = this;

			var sPath = evt.getSource().getBindingContext("tabModel").sPath;
			sPath = sPath.slice(1);
			sPath = sPath.split("/")[1];
			var oModel = that.getView().byId("errorLogTable").getModel("tabModel").getData().results[sPath];
			var arrayFinal = [];
			arrayFinal.push(oModel);
			var oEntry = {
				"FirstTime": "",
				"StartDate": null,
				"EndDate": null,
				"UserId": "",
				"JdocNo": "",
				"ActiveRevision": "",
				"AllRevision": "",
				"NavToMsg": [{

					"EMessage": "Invalid input for fetching error log data",
					"EMsgType": "E",
					"EMsgId": "ZPLM_JDOC",
					"EMsgNo": "181",
					"EErrObj": ""
				}],
				"NavToErrorLog": arrayFinal
			};
			sap.ui.core.BusyIndicator.show(0);
			var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
			oModelVariantO1.create('/ErrorLogInputsSet', oEntry, null, function(oData, response) {

					//	console.log(oData);

					if (oData.NavToMsg.results[0].EMsgType === "S") {
						sap.ui.core.BusyIndicator.hide();
						setTimeout(function() {
							MessageToast.show(oData.NavToMsg.results[0].EMessage);
						}, 100);
						that.getView().byId("errorLogTable").getModel("tabModel").refresh();
					} else if (oData.NavToMsg.results[0].EMsgType === "E") {
						sap.ui.core.BusyIndicator.hide();
						setTimeout(function() {
							MessageToast.show(oData.NavToMsg.results[0].EMessage);
						}, 100);
					}

				},
				function() {
					sap.ui.core.BusyIndicator.hide();

				});

		},
		onCloseErrorFragment: function(evt) {
			this._oResetPasswordDialog.close();
			this._oResetPasswordDialog.destroy();
			this._oResetPasswordDialog = undefined;

		},
		searchBasedOnUser: function(evt) {
			
			var responseMessageList = [];
			var data = null;
			if (this.getView().byId("userId").getTokens().length > 0) {
				if (this.getView().byId("userId").getTokens()[0].getProperty("text") === null || this.getView().byId("userId").getTokens()[0].getProperty(
						"text") === "" || this.getView().byId(
						"userId").getTokens()[0].getProperty("text") === undefined) {
					data = {
						"Message": "UserId is Mandatory Field",
						"MessageType": "Error"
					};
					responseMessageList.push(data);

				}
			} else {
				data = {
					"Message": "Invalid Input Please choose from the suggested User Id's",
					"MessageType": "Error"
				};
				responseMessageList.push(data);
			}
			if (this.getView().byId("startDate").getValue() === null || this.getView().byId("startDate").getValue() === "" ||
				this.getView().byId("startDate").getValue() === undefined) {
				data = {
					"Message": "Start Date is Mandatory Field",
					"MessageType": "Error"
				};
				responseMessageList.push(data);

			}
			if (this.getView().byId("endDate").getValue() === null || this.getView().byId("endDate").getValue() === "" ||
				this.getView().byId("endDate").getValue() === undefined) {
				data = {
					"Message": "End Date is Mandatory Field",
					"MessageType": "Error"
				};
				responseMessageList.push(data);

			}
			if (responseMessageList.length > 0) {
				var viewModel = new sap.ui.model.json.JSONModel();
				viewModel.setData({
					messagesLength: responseMessageList.length + ''
				});
				this.byId("popoverErrorLog").setModel(viewModel);

				sap.ui.getCore().getModel("errorModel").setData(responseMessageList);
				sap.ui.getCore().getModel("errorModel").refresh();

				this.handleMessagePopoverPress(evt);

				this.byId("popoverErrorLog").setType("Emphasized");
			} else {
				var that = this;
				sap.ui.core.BusyIndicator.show(0);
				var startDate = formatter.oDataDateTimeFormatterDatePicker(this.byId("startDate").getValue());
				var endDate = formatter.oDataDateTimeFormatterDatePicker(this.byId("endDate").getValue());
				
				var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
				var oFilter1 = new sap.ui.model.Filter("UserId", "EQ", this.byId("userId").getTokens()[0].getProperty("text"));
				var oFilter2 = new sap.ui.model.Filter("StartDate", "EQ", startDate);
				var oFilter3 = new sap.ui.model.Filter("EndDate", "EQ", endDate);
				var oJsonModelErrorLog = new sap.ui.model.json.JSONModel();
				oModelVariantO1.read("ErrorLogInputsSet", {
					filters: [oFilter1, oFilter2, oFilter3],
					urlParameters: {
						"$expand": ["NavToErrorLog,NavToMsg"]
					},
					success: function(oData, response) {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results[0].NavToMsg.results[0].EMsgType === "" || oData.results[0].NavToMsg.results[0].EMsgType === "S") {

							if (oData.results[0].NavToErrorLog.results.length > 0) {
								that.byId("idonexporterrorlog").setEnabled(true);
								//	oJsonModelErrorLog.setData(oData.results[0].NavToErrorLog);
								that.byId("errorLogTableAdvancedSearch").setModel(oJsonModelErrorLog, "tabModel");
								that.byId("errorLogTableAdvancedSearch").getModel("tabModel").setData(oData.results[0].NavToErrorLog);
								that.byId("errorLogTableAdvancedSearch").getModel("tabModel").refresh();
								that.byId("titleIdAdvanced").setText("Error Log - " + oData.results[0].NavToErrorLog.results.length);
								//	that._oResetPasswordDialog.close();
								//	that._oResetPasswordDialog.destroy();
								//	that._oResetPasswordDialog = undefined;
							} else {

								var responseMessageList = [];
								var data = null;
								data = {
									"Message": "No Data Found for this Combination",
									"MessageType": "Error"
								};
								responseMessageList.push(data);
								if (responseMessageList.length > 0) {
									var viewModel = new sap.ui.model.json.JSONModel();
									viewModel.setData({
										messagesLength: responseMessageList.length + ''
									});
									that.byId("popoverErrorLog").setModel(viewModel);

									sap.ui.getCore().getModel("errorModel").setData(responseMessageList);
									sap.ui.getCore().getModel("errorModel").refresh();

									that.handleMessagePopoverPress(evt);

									that.byId("popoverErrorLog").setType("Emphasized");
								}

							}

						} else if (oData.results[0].NavToMsg.results[0].EMsgType === "E") {
							var responseMessageList = [];
							var data = null;
							data = {
								"Message": oData.results[0].NavToMsg.results[0].EMessage,
								"MessageType": "Error"
							};
							responseMessageList.push(data);
							if (responseMessageList.length > 0) {
								var viewModel = new sap.ui.model.json.JSONModel();
								viewModel.setData({
									messagesLength: responseMessageList.length + ''
								});
								that.byId("popoverErrorLog").setModel(viewModel);

								sap.ui.getCore().getModel("errorModel").setData(responseMessageList);
								sap.ui.getCore().getModel("errorModel").refresh();

								that.handleMessagePopoverPress(evt);

								that.byId("popoverErrorLog").setType("Emphasized");
							}
						}
					},

					error: function(err) {
						//		alert("Service Failed");
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}

		},
		//MTest-JDoc360-App-Issue#197: 
		//implemented excel export: Begin
			onExportAdvanceSearchErrorlog : function(){
			var that = this;
	
		var data2 = that.byId("errorLogTableAdvancedSearch").getModel("tabModel");//.oData.results;
		
		
				var oExport = new Export({

				// Type that will be used to generate the content. Own ExportType's can be created to support other formats
				exportType : new ExportTypeCSV({
					separatorChar : ",",
					charset : "utf-8"
				}),
				
				// Pass in the model created above
				models : data2,
				
			
				// binding information for the rows aggregation
				rows : {
					path : "/results"
				},

				// column definitions with column name and binding info for the content

				columns : [
					{
						name : "Message Type",
						template : {
							content : "ERROR"
						}
				    },
				    {
						name : "Error Type",
						template : {
							content : "{MsgTyp}"
						}
				    },
					{
						name : "Log No",
						template : {
							
							content : {	
							parts: ["LogNo"],
                        formatter: function(LogNo) {

                            return "	" + LogNo; // to retain leading zeros, press TAB on the keyboard and concat it with LogNo
                        }
							}
						}
				    },
				    
				    {
						name : "JDoc Number",
						template : {
							content : "{JdocNumber}"
						}
				    },
				    {
						name : "JDoc Rev",
						template : {
							content : "{JdocRevision}"
						}
				    },
				    {
						name : "SAP DIR Number",
						template : {
							content : {
								parts : ["DocumentNumber"],
								formatter: function(docno) {

                            return "	" + docno; // to retain long numbers, press TAB on the keyboard and concat with docno
                        }
						}
						}
				    },
				     {
						name : "User",
						template : {
							content : "{UserId}"
						}
				    },
				     {
						name : "Log Date",
						template : {
							content : {
								parts : ["LogDate"],
								formatter : function(date){
										if (date !== undefined && date !== null) {
				var oLocale = sap.ui.getCore().getConfiguration().getFormatSettings().getFormatLocale();
				
				
				var oDateFormat = DateFormat.getDateInstance({
					scale: "medium",
					pattern: "dd-MMM-yyyy",
					UTC: true
				}, oLocale);

				var subFromDate = oDateFormat.format(new Date(date));
			
				return subFromDate;
			} else {
				return "";
			}
								}
						}
						}
				    },
				     {
						name : "Log Time",
						template : {
							content : "{LogTime}"
						}
				    },
				    {
						name : "Message",
						template : {
							content : "{ErrorMessage}"
						}
				    },
				      {
						name : "Site",
						template : {
							content : "{SiteId}"
						}
				    }
				]
			});

			// download exported file
			oExport.saveFile().catch(function(oError) {
				sap.m.MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});
		},
		//implemented excel export: End
		onValueSearchCollaborator: function(evt) {
			//add
			if (!this._collaboratorListDialog) {
				this._collaboratorListDialog = sap.ui.xmlfragment(this.getView().getId(),
					"JABIL_FINAL_JDOC360.fragments.CollaboratorListDialogDraft", this);
				this.getView().addDependent(this._collaboratorListDialog);
			}
			//	this.selectedCollaboratorInputIndex = evt.getSource().getBinding("value").getContext().getPath().split("/")[2];
			this._collaboratorListDialog.open();
			var oJsonModel = new sap.ui.model.json.JSONModel();
			this.byId("collaboratorListTable").setModel(oJsonModel, "collaboratorList");
			this.byId("collaboratorId").setValue("");
			this.byId("collaboratorFirstName").setValue("");
			this.byId("collaboratorLastName").setValue("");

		},
		cancelAddCollaborator: function(evt) {
			this._collaboratorListDialog.close();
			this._collaboratorListDialog.destroy();
			this._collaboratorListDialog = undefined;

		},
		onCollaboratorSelect: function(evt) {

			var userId = evt.getSource().getAggregation("cells")[0].getProperty("text");
			this.byId("userId").setValue(userId);
			//	this.byId("collaboratorInput").setValue(userId);
			//	this.byId("tableForCollaboration").getModel("tabModel").refresh(true);
			this._collaboratorListDialog.close();
			this._collaboratorListDialog.destroy();
			this._collaboratorListDialog = undefined;
		},
		searchCollaborator: function(oEvent) { //add
			var that = this;
			that.byId("collaboratorListTable").setBusy(true);

			var collaboratorId = this.byId("collaboratorId").getValue();
			var firstName = this.byId("collaboratorFirstName").getValue();
			var lastName = this.byId("collaboratorLastName").getValue();

			var oFilter1 = new sap.ui.model.Filter("Bname", "Contains", collaboratorId);
			var oFilter2 = new sap.ui.model.Filter("McNamefir", "Contains", firstName);
			var oFilter3 = new sap.ui.model.Filter("McNamelas", "Contains", lastName);

			var oModelVariant = new sap.ui.model.odata.ODataModel(
				"/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/");
			var oJsonModel = new sap.ui.model.json.JSONModel();
			//	!controlValue.replace(/\s/g, '').length
			if (collaboratorId.replace(/\s/g, '').length === 0 && firstName.replace(/\s/g, '').length === 0 && lastName.replace(/\s/g, '').length ===
				0) {
				that.byId("collaboratorListTable").setNoDataText("Please Enter a Value for Above Filters");
			} else {
				sap.ui.core.BusyIndicator.show(0);
				oModelVariant.read("/SrchHelpErrorLogUsersSet", {
					filters: [oFilter1, oFilter2, oFilter3],
					success: function(oData, response) {

						sap.ui.core.BusyIndicator.hide();
						oJsonModel.setData(oData);

						//if()
						that.byId("collaboratorListTable").setModel(oJsonModel, "collaboratorList");
						that.byId("collaboratorListTable").setBusy(false);
					}

				});
			}
			that.byId("collaboratorListTable").setBusy(false);

		},
		searchBasedOnJdocNumber: function(evt) {
	
			var responseMessageList = [];
			var data = null;
			if (this.getView().byId("jdocNumber").getTokens().length > 0) {
				if (this.getView().byId("jdocNumber").getTokens()[0].getProperty("text") === null || this.getView().byId("jdocNumber").getTokens()[
						0].getProperty("text") === "" ||
					this.getView().byId("jdocNumber").getTokens()[0].getProperty("text") === undefined) {
					data = {
						"Message": "Jdoc Number is Mandatory Field",
						"MessageType": "Error"
					};
					responseMessageList.push(data);

				}

			} else {
				data = {
					"Message": "Invalid Input Please choose from the suggested Document No's",
					"MessageType": "Error"
				};
				responseMessageList.push(data);
			}
			if (!this.byId("activeRevision").getSelected() && !this.byId("allRevision").getSelected()) {
				data = {
					"Message": "Select either All revision or active revision option",
					"MessageType": "Error"
				};
				responseMessageList.push(data);

			}

			if (responseMessageList.length > 0) {
				var viewModel = new sap.ui.model.json.JSONModel();
				viewModel.setData({
					messagesLength: responseMessageList.length + ''
				});
				this.byId("popoverErrorLog").setModel(viewModel);

				sap.ui.getCore().getModel("errorModel").setData(responseMessageList);
				sap.ui.getCore().getModel("errorModel").refresh();

				this.handleMessagePopoverPress(evt);

				this.byId("popoverErrorLog").setType("Emphasized");
			} else {
				var that = this;
				sap.ui.core.BusyIndicator.show(0);
				var oModelVariantO1 = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZOD_PLM_JDOC_360_SRV/", true);
				var oFilter1 = new sap.ui.model.Filter("JdocNo", "EQ", this.byId("jdocNumber").getTokens()[0].getProperty("text"));
				var activeRevision = "";
				var allRevision = "";
				if (this.byId("activeRevision").getSelected()) {
					activeRevision = "X";
				}
				if (this.byId("allRevision").getSelected()) {
					allRevision = "X";
				}
				var oFilter2 = new sap.ui.model.Filter("AllRevision", "EQ", allRevision);
				var oFilter3 = new sap.ui.model.Filter("ActiveRevision", "EQ", activeRevision);
				var oJsonModelErrorLog = new sap.ui.model.json.JSONModel();
				oModelVariantO1.read("ErrorLogInputsSet", {
					filters: [oFilter1, oFilter2, oFilter3],
					urlParameters: {
						"$expand": ["NavToErrorLog,NavToMsg"]
					},
					success: function(oData, response) {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results[0].NavToMsg.results[0].EMsgType === "" || oData.results[0].NavToMsg.results[0].EMsgType === "S") {

							if (oData.results[0].NavToErrorLog.results.length > 0) {
								that.byId("idonexporterrorlog").setEnabled(true);
								that.byId("errorLogTableAdvancedSearch").setModel(oJsonModelErrorLog, "tabModel");
								that.byId("errorLogTableAdvancedSearch").getModel("tabModel").setData(oData.results[0].NavToErrorLog);
								that.byId("errorLogTableAdvancedSearch").getModel("tabModel").refresh();
								that.byId("titleIdAdvanced").setText("Error Log - " + oData.results[0].NavToErrorLog.results.length);

								/*that._oResetPasswordDialog.close();
								that._oResetPasswordDialog.destroy();
								that._oResetPasswordDialog = undefined;*/
							} else {

								var responseMessageList = [];
								var data = null;
								data = {
									"Message": "No Data Found for this Combination",
									"MessageType": "Error"
								};
								responseMessageList.push(data);
								if (responseMessageList.length > 0) {
									var viewModel = new sap.ui.model.json.JSONModel();
									viewModel.setData({
										messagesLength: responseMessageList.length + ''
									});
									that.byId("popoverErrorLog").setModel(viewModel);

									sap.ui.getCore().getModel("errorModel").setData(responseMessageList);
									sap.ui.getCore().getModel("errorModel").refresh();

									that.handleMessagePopoverPress(evt);

									that.byId("popoverErrorLog").setType("Emphasized");
								}

							}

						} else if (oData.results[0].NavToMsg.results[0].EMsgType === "E") {
							var responseMessageList = [];
							var data = null;
							data = {
								"Message": oData.results[0].NavToMsg.results[0].EMessage,
								"MessageType": "Error"
							};
							responseMessageList.push(data);
							if (responseMessageList.length > 0) {
								var viewModel = new sap.ui.model.json.JSONModel();
								viewModel.setData({
									messagesLength: responseMessageList.length + ''
								});
								that.byId("popoverErrorLog").setModel(viewModel);

								sap.ui.getCore().getModel("errorModel").setData(responseMessageList);
								sap.ui.getCore().getModel("errorModel").refresh();

								that.handleMessagePopoverPress(evt);

								that.byId("popoverErrorLog").setType("Emphasized");
							}
						}
					},

					error: function(err) {
						//		alert("Service Failed");
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		},
		handleMessagePopoverPress: function(oEvent) {

			if (sap.ui.getCore().getModel("errorModel").getData() !== null && sap.ui.getCore().getModel("errorModel").getData() !== undefined &&
				sap.ui.getCore().getModel("errorModel").getData().length > 0) {
				var responseModelData = sap.ui.getCore().getModel("errorModel").getData();
				var oMessageTemplate;
				for (var i = 0; i < responseModelData.length; i++) {
					oMessageTemplate = new MessagePopoverItem({
						title: '{Message}',
						type: '{MessageType}'

					});
				}
			} else {
				oMessageTemplate = new MessagePopoverItem();
			}

			var oMessagePopover = new MessagePopover({
				items: {
					id: "messagePopover",
					path: '/',
					template: oMessageTemplate
				}
			});
			oMessagePopover.setModel(sap.ui.getCore().getModel("errorModel"));

			oMessagePopover.openBy(this.byId("popoverErrorLog"));

		},
		onSelectUserName: function(evt) {
			this.byId("panelUserName").setVisible(true);
			this.byId("panelJdocNumber").setVisible(false);

		},
		onSelectJdocNumber: function(evt) {
			this.byId("panelUserName").setVisible(false);
			this.byId("panelJdocNumber").setVisible(true);

		},
		onSearch:function(oEvent){
			if(oEvent.getParameters()[0].selectionSet.length === 1){
				if(oEvent.getParameters().id.match("smartFilterBarInProcessChart") !== null){
				this.byId("customerIdDropDown").removeAllSelectedItem();
				this.byId("typeIdDropdown").removeAllSelectedItem();
				this.byId("deptIdDropDown").removeAllSelectedItem();
				this.byId("statusDropDown").removeAllSelectedItem();
				this.byId("pendingUserDropDown").removeAllSelectedItem();
				} else if(oEvent.getParameters().id.match("smartFilterBarDocStatus") !== null){
				this.byId("typeIdDropdownDocStatus").removeAllSelectedItem();
				this.byId("customerIdDropDownDocStatus").removeAllSelectedItem();
				this.byId("authorIdDropDownDocStatus").removeAllSelectedItem();
				this.byId("ownerIdDropDownDocStatus").removeAllSelectedItem();
				}else if(oEvent.getParameters().id.match("smartFilterBarDocType") !== null){
				this.byId("customerIdDropDownDocType").removeAllSelectedItem();
				this.byId("statusIdDropDownDocType").removeAllSelectedItem();
				this.byId("authorIdDropDownDocType").removeAllSelectedItem();
				this.byId("ownerIdDropDownDocType").removeAllSelectedItem();
				}else if(oEvent.getParameters().id.match("smartFilterBarPeriodicReview") !== null){
				this.byId("typeIdDropdownPeriodicReview").removeAllSelectedItem();
				this.byId("customerIdDropDownPeriodicReview").removeAllSelectedItem();
				this.byId("deptIdDropDownPeriodicReview").removeAllSelectedItem();
				this.byId("authorIdDropDownPeriodicReview").removeAllSelectedItem();
				this.byId("ownerIdDropDownPeriodicReview").removeAllSelectedItem();
				this.byId("pendingUserDropDownPeriodicReview").removeAllSelectedItem();
				}else if(oEvent.getParameters().id.match("smartFilterBarMasterList") !== null){
				// this.byId("typeIdDropdownDocStatus").removeAllSelectedItem();
				// this.byId("customerIdDropDownDocStatus").removeAllSelectedItem();
				// this.byId("authorIdDropDownDocStatus").removeAllSelectedItem();
				// this.byId("ownerIdDropDownDocStatus").removeAllSelectedItem();
				}else if(oEvent.getParameters().id.match("smartFilterBarLinkedDocs") !== null){
				this.byId("docNumberDropDown").removeAllSelectedItem();
				// this.byId("customerIdDropDownDocStatus").removeAllSelectedItem();
				// this.byId("authorIdDropDownDocStatus").removeAllSelectedItem();
				// this.byId("ownerIdDropDownDocStatus").removeAllSelectedItem();
				}else if(oEvent.getParameters().id.match("smartFilterBarControlledCopiesReport") !== null){
				this.byId("docNumberDropDown").removeAllSelectedItem();
				// this.byId("customerIdDropDownDocStatus").removeAllSelectedItem();
				// this.byId("authorIdDropDownDocStatus").removeAllSelectedItem();
				// this.byId("ownerIdDropDownDocStatus").removeAllSelectedItem();
				}
				
			}
			
		},
		onClear: function(oEvent) {		
		// var oItems = this.oFilterBar.getAllFilterItems(true);
		// for (var i=0; i < oItems.length; i++) {							
		// 	var oControl = this.oFilterBar.determineControlByFilterItem(oItems[i]);
		// 	if (oControl) {
		// 		oControl.setValue("");
		// 	}
		// }
	},	
		controlledCopiesRecievedData: function(oEvent) {
			/*var filter = new Filter("PlantNo", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter); */
			/*	this.dataRecievedControlledCopies = new sap.ui.model.json.JSONModel();
				this.dataRecievedControlledCopies.setData(oEvent.getParameters().getParameter("data").results);
				this.dataRecievedControlledCopies.refresh();*/
		}
	});
});